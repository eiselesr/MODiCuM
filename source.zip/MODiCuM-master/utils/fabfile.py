import sys
import os
import fabric.api as fabi

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))

import config_main as cfg
import config_private as private

ALL = list(cfg.hosts.values())

fabi.env.roledefs = {
    'ALL' : ALL,
	'testVU' : ["129.59.105.167"],
	'testHome' : ["192.168.137.227"],
	'testCluster' : [cfg.hosts['bbb-b4bc']]
}

fabi.env.port=private.port

fabi.env.key_filename = private.rsa_private_key
fabi.env.skip_bad_hosts = True
fabi.env.warn_only = True
fabi.env.abort_on_prompts=True

@fabi.task
def miner(ip=cfg.MINER_IP):
	tsk = "tmux send-keys -t miner"
	geth = 'geth-linux-amd64/geth'
	cmd = []
	cmd.append("tmux new -d -s miner;")# '%s'" %(cd)
	cmd.append("%s 'cd %s' C-m;" %(tsk, MINER_DIR))
	cmd.append("%s '%s --datadir eth/ init genesis-data.json' C-m;" %(tsk, geth))
	cmd.append("%s '%s account new --password password.txt --datadir eth/' C-m;" %(tsk, geth))
	cmd.append("%s '%s --datadir eth/ --rpc --rpcport %s --rpcaddr %s --nodiscover \
	               --rpcapi \"eth,web3,admin,miner,net,db\" --password password.txt --verbosity 3 --unlock 0 \
				   --networkid 15 --mine |& tee miner.log' C-m;" %(tsk, geth,MINER_PORT,MINER_IP))
	# tmux send-keys -t $miner "geth-linux-amd64/geth account new --password password.txt --datadir eth/" C-m

	out = fabi.execute(runCommand, ''.join(cmd), hosts=ip)
	print("done")
	print(out[ip])
@fabi.task
def stopminer(ip):
	cmd = "tmux kill-session -t miner"
	out = fabi.execute(runCommand, cmd, hosts=ip)


#@fabi.parallel
@fabi.task
#http://docs.fabfile.org/en/2.3/cli.html#executing-arbitrary-ad-hoc-commands
def runCommand(command,verbose=False):
	"""run with fab -R '<role to run command on, e.g c2_1>' runCommand:<command to run>
		or to run on a specific host: fab -H '10.0.2.194:2222' runCommand:'hostname'"""
	results = ''
	print(verbose)
	with fabi.hide('output', 'running', 'warnings', 'aborts'), fabi.settings(warn_only=True):
		results = fabi.run(command)
	if verbose:
		print(results)
	return(results)

@fabi.task
def test(ip):
    cmd="tmux new -d -s miner;"
    fabi.local("ls")
    fabi.execute(runCommand,cmd,hosts=ip)
