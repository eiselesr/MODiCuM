import unittest
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.DirectoryClient as DirectoryClient

class TestCase(unittest.TestCase):
    def setUp(self):
        self.host = "129.59.105.24"
        self.port = cfg.DIR_PORT
        self.sftport = private.port
        self.jcID = "user_4"
        self.rpID = "user_5"
        self.job = "matrix_multiplication"
        self.localpath = cfg.WORKPATH
        self.sshpath = "/home/riaps/.ssh/cluster_2018_9_10"
        self.pubkey = private.pubkey

    def test_permission(self):
        DC = DirectoryClient.DirectoryClient()
        responseJC = DC.getPermission(self.host,self.port,self.jcID,self.job,self.pubkey)
        print(responseJC)

    def test_publish(self):
        JC = DirectoryClient.DirectoryClient()
        responseJC = JC.getPermission(self.host,self.port,self.jcID,self.job,self.pubkey)
        print(responseJC)
        JC.publishData(self.host,self.sftport,self.jcID,self.job,self.localpath,self.sshpath)
        print("done")

    def test_getData(self):
        # self.test_publish()
        RP = DirectoryClient.DirectoryClient()
        responseRP = RP.getPermission(self.host,self.port,self.rpID,self.job,self.pubkey)
        RP.getData(self.host,self.sftport,self.rpID,self.jcID,self.job,self.localpath+"/gotJob",self.sshpath)
        print("done")






# JC.getResult(host,port,rpID,jcID,job,localPath,sshpath)
