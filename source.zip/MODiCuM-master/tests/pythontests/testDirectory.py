import unittest
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.Directory as Directory

print("hello")

class DirectoryTestCase(unittest.TestCase):

    def test_permission(self):
        D = Directory.Directory()
        ID="user_3"
        job = "matrix_multiplication"
        pubkey = private.pubkey
        D.getPermission(ID,job,pubkey)

    def test_Server(self):
        D = Directory.Directory()
        D.startServer(port=cfg.DIR_PORT,childport=cfg.CHILD_PORT)
