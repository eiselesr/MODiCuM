import unittest
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.Solver as Solver


class TestCase(unittest.TestCase):
    def setUp(self):
        self.geth_ip = cfg.MINER_IP
        self.geth_port = cfg.MINER_PORT
        self.manager_ip = cfg.MANA_IP


    def test_init(self):
        Solver.Solver(self.geth_ip, self.geth_port, self.manager_ip)
