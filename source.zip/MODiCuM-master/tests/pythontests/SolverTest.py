import sys
import os
import time
import datetime

POLLING_INTERVAL = 1 # seconds

#TODO: switch to using Python datatypes?

class Mediator():
  def __init__(self, arch, instructionPrice, bandwidthPrice, dockerBandwidthPrice):
    self.arch = arch
    self.instructionPrice = instructionPrice
    self.bandwidthPrice = bandwidthPrice
    self.dockerBandwidthPrice = dockerBandwidthPrice
    #self.supportedDirectories = supportedDirectories
    #self.layers = layers
  def __eq__(self, other):
    """Overrides the default implementation"""
    if isinstance(other, Mediator):
        return (self.arch == other.arch and self.instructionPrice == other.instructionPrice and self.bandwidthPrice == other.bandwidthPrice and self.dockerBandwidthPrice == other.dockerBandwidthPrice)
    return False

class ResourceProvider():
  def __init__(self, arch, timePerInstruction):
    self.arch = arch
    #timePerInstruction must be in microseconds
    self.timePerInstruction = timePerInstruction
    self.trustedMediators = []
    #self.trustedMediators.append(trustedMediators)
    #for i in trustedMediatorsDict:
    #    self.trustedMediators.append(Mediator(i['arch'], i['instructionPrice'], i['bandwidthPrice'], i['dockerBandwidthPrice']))

    #self.trustedMediators = trustedMediators
    #self.layers = layers
    #self.supportedDirectories=supportedDirectories

class JobCreator():
 def __init__(self):
    self.trustedMediators=[]

class JobOffer():
    #JobOfferPosted(uint offerId, address jobCreator, uint size, Architecture arch, uint instructionLimit, uint ramLimit, uint localStorageLimit, uint bandwidthLimit, uint instructionMaxPrice, uint bandwidthMaxPrice, uint dockerBandwidthMaxPrice, uint256 completionDeadline);
  def __init__(self, offerId, jobCreator, size, arch, instructionLimit, ramLimit, localStorageLimit, bandwidthLimit, instructionMaxPrice, bandwidthMaxPrice, dockerBandwidthMaxPrice, completionDeadline, deposit):
    self.offerId = offerId
    self.jobCreator = jobCreator
    self.size = size;
    self.arch = arch
    self.instructionLimit = instructionLimit
    self.ramLimit = ramLimit
    self.localStorageLimit = localStorageLimit
    self.bandwidthLimit = bandwidthLimit
    self.instructionMaxPrice = instructionMaxPrice
    self.bandwidthMaxPrice = bandwidthMaxPrice
    self.dockerBandwidthMaxPrice = dockerBandwidthMaxPrice
    #self.matchDeadline = matchDeadline
    self.completionDeadline = completionDeadline
    self.deposit = deposit
    #self.directory = directory
    #self.layers = layers

class ResourceOffer():
    #ResourceOfferPosted(uint offerId, address resourceProvider, uint instructionPrice, uint instructionCap, uint memoryCap, uint localStorageCap, uint bandwidthCap, uint bandwidthPrice, uint dockerBandwidthCap, uint dockerBandwidthPrice);
  def __init__(self, offerId, resourceProvider, instructionPrice, instructionCap, memoryCap, localStorageCap, bandwidthCap, bandwidthPrice, dockerBandwidthCap, dockerBandwidthPrice, deposit):
    self.offerId = offerId
    #print(resourceProviderDict)
    self.resourceProvider =resourceProvider
    self.instructionPrice = instructionPrice
    self.instructionCap = instructionCap
    self.memoryCap = memoryCap
    self.localStorageCap = localStorageCap
    self.bandwidthCap = bandwidthCap
    self.bandwidthPrice = bandwidthPrice
    self.dockerBandwidthCap = dockerBandwidthCap
    self.dockerBandwidthPrice = dockerBandwidthPrice
    self.deposit = deposit

class Solver():
    def __init__(self):
        #self.account = client.accounts()[0] # TODO: pick different account for each solver (does not matter if there is only one solver)
        #self.contract = ModicumContract(client, self.contract_address)
        self.mediators = {}
        self.resource_providers = {}
        self.job_creators = {}
        self.resource_offers = {}
        self.job_offers = {}
        #super(Solver, self).__init__()

    def matchable(self, resource_offer, job_offer):
        #instructionCap >= instructionLimit
        #print("Begin Matching")
        if resource_offer.instructionCap < job_offer.instructionLimit:
            #self.logger.info("Too many instructions")
            return(False, False)

        #localStorageCap>= localStorageLimit
        if resource_offer.localStorageCap < job_offer.localStorageLimit:
            #self.logger.info("Too much disk")
            return(False, False)
        #bandwidthCap >= bandwidthLimit
        if resource_offer.bandwidthCap < job_offer.bandwidthLimit:
            #self.logger.info("Too much data")
            return(False, False)
        #instructionPrice >= instructionMaxPrice
        if resource_offer.instructionPrice > job_offer.instructionMaxPrice:
            #self.logger.info("Instructions too expensive")
            return(False, False)
        #bandwidthPrice >= bandwidthMaxPrice
        if resource_offer.bandwidthPrice > job_offer.bandwidthMaxPrice:
            #self.logger.info("Data too expensive")
            return(False, False)

        # if (datetime.datetime.now() + datetime.timedelta(0,0,self.resource_providers[resource_offer.resourceProvider].timePerInstruction  * job_offer.instructionLimit)) > job_offer.completionDeadline:
        #if (time.time() +             job_offer.instructionLimit *             self.resource_providers[resource_offer.resourceProvider].timePerInstruction) > job_offer.completionDeadline:

            #self.logger.info("Not Enough Time to complete")
            #return(False, False)

        #JO.arch = RP.arch
        if self.resource_providers[resource_offer.resourceProvider].arch != job_offer.arch:
            #self.logger.info("Architecture mismatch")
            return(False, False)

        # JO.trustedMediators = RP.trustedMediators
        for i in self.resource_providers[resource_offer.resourceProvider].trustedMediators:
            for j in self.job_creators[job_offer.jobCreator].trustedMediators:
                if i == j:
                    #Deposits >=jobDeposit
                    sharedMediator = self.mediators[i]
                    mediatorDeposit = job_offer.instructionLimit * sharedMediator.instructionPrice + job_offer.bandwidthLimit * sharedMediator.bandwidthPrice + job_offer.size * sharedMediator.dockerBandwidthPrice
                    jobDeposit = job_offer.instructionLimit * resource_offer.instructionPrice + job_offer.bandwidthLimit * resource_offer.bandwidthPrice + job_offer.size * resource_offer.dockerBandwidthPrice
                    #Assume that Fine is 10xprice
                    fine = 100 * jobDeposit #TODO make finerate global constant

                    if ((jobDeposit > (resource_offer.deposit + mediatorDeposit)) or (jobDeposit > (job_offer.deposit + mediatorDeposit)) ):
                        return(False, False)
                    return(True,i)
        #self.logger.info("No Mediator") #only will reach here if there is no mediator
        #self.logger.info(self.resource_providers[resource_offer.resourceProvider].trustedMediators)
        #self.logger.info(self.job_creators[job_offer.jobCreator].trustedMediators)


        return(False, False)

    def bfs(self, resourceList, jobList, edgeList, currentNode, jobsVisited, resourcesVisited, resourceOrJob, prevTraversedJob, prevTraversedResource):
        #Start searching all connected nodes
        if (resourceOrJob == 'resource'):
            #prevTraversedResource.append(currentNode)
            for i in resourceList[currentNode]:
                #if i not in prevTraversedJob:
                if jobsVisited[i] == 0: #i is not visited, free nodes
                    edgeList.append([i,currentNode])
                    return(True, edgeList)
            #recursively search if not found
            for i in resourceList[currentNode]:
                if i not in prevTraversedJob:
                    edgeList2 = edgeList
                    prevTraversedJob2 = prevTraversedResource
                    prevTraversedJob2.append(i)
                    edgeList2.append([i,currentNode])
                    [found, edgeList3] = self.bfs(resourceList, jobList,edgeList2, i, jobsVisited, resourcesVisited, 'job', prevTraversedJob2, prevTraversedResource)
                    if found: #if found == True
                        return(found,edgeList3)

        elif resourceOrJob == 'job':
            #prevTraversedJob.append(currentNode)
            for i in jobList[currentNode]:
                #if i not in prevTraversedResource:
                if resourcesVisited[i] == 0: #i is not visited, free node
                    edgeList.append([currentNode,i])
                    return(True, edgeList)
            #recursively search if not found
            for i in jobList[currentNode]:
                if i not in prevTraversedResource:
                    edgeList2 = edgeList
                    prevTraversedResource2 = prevTraversedResource
                    prevTraversedResource2.append(i)
                    edgeList2.append([currentNode,i])
                    [found, edgeList3 ] = self.bfs(resourceList, jobList,edgeList2, i, jobsVisited, resourcesVisited, 'resource', prevTraversedJob, prevTraversedResource2)
                    if found: #if found == True
                        return(found, edgeList3)

        return(False, [])



        #maximum bipartate matching algorithm
    def HopcroftKarp(self):
     #Create graph
        jobList={}
        resourceList = {}
        mediatorList = {}

        edges = []
        #list of visited nodes
        visitedJob = {}
        visitedResource = {}
        for j in self.resource_offers:
            resourceList[j]=[]
            visitedResource[j]=0

        #create edges for each node
        print("job_offers = "+str(self.job_offers))
        print("resource_offers = "+str(self.resource_offers))
        for i in self.job_offers:
            edges = []
            visitedJob[i]=0
            mediatorList[i] = {}
            for j in self.resource_offers:
                [result,mediator] = self.matchable(self.resource_offers[j],self.job_offers[i])
                if (result):
                    #self.logger.info("Matchable")
                    edges.append(j)
                    resourceList[j].append(i)
                    mediatorList[i][j]=mediator
                #else:
                    #self.logger.info("Not Matchable")
            jobList[i] = edges

        #this uses Hopcroft-Karp algorithm for maximal bipartate matchingMediator
        P = []
        print("jobList = "+str(jobList))
        for i in jobList:
            [result, newEdges] = self.bfs(resourceList, jobList, [], i, visitedJob, visitedResource, 'job', [i], [])
            if (result != False): #Important step for null results
                for j in newEdges:
                    visitedJob[j[0]]=1
                    visitedResource[j[1]]=1
                    mediator = mediatorList[j[0]][j[1]]
                    j.append(mediator)
                    if result: #if we found a successful graph
                        if j not in P:
                            P.append(j)
                        else:
                            P.remove(j) #Why would you remove it?
            print("\nedgelist = " + str(newEdges) )
            print("P = "+str(P)+str("\n"))
        return(P)


    def run(self, events):
        print("Removed event polling functionality")
        #logging.info("Entering main loop...")
        print("Entering Main Loop")
        #next_polling = time() + POLLING_INTERVAL

         #logging.debug("Polling events...")
        for event in events:
           name = event['name'] #name of event
           params=event['params'] #parameters of event
           #logging.info("{}({}).".format(name, events[name]))
           if name == "mediatorRegistered":
             self.mediators[params['addr']] = Mediator(params['arch'], params['instructionPrice'], params['bandwidthPrice'], params['dockerBandwidthPrice'])
           elif name == "resourceProviderRegistered":
             self.resource_providers[params['addr']] = ResourceProvider(params['arch'], params['timePerInstruction'])
           elif name == "jobCreatorRegistered":
             self.job_creators[params['addr']] = JobCreator()
           elif name == "ResourceProviderAddedTrustedMediator":
             self.resource_providers[params['addr']].trustedMediators.append(params['mediator'])
           elif name == "JobCreatorAddedTrustedMediator":
             self.job_creators[params['addr']].trustedMediators.append(params['mediator'])
           elif name == "resourceOfferPosted":
             offer  = ResourceOffer(params['offerId'], params['resourceProvider'], params['instructionPrice'], params['instructionCap'], params['memoryCap'], params['localStorageCap'], params['bandwidthCap'], params['bandwidthPrice'], params['dockerBandwidthCap'], params['dockerBandwidthPrice'], params['deposit'] )
             self.resource_offers[params['offerId']] =  offer
           elif name == "jobOfferPosted":
             offer = JobOffer(params['offerId'], params['jobCreator'], params['size'], params['arch'], params['instructionLimit'], params['ramLimit'], params['localStorageLimit'], params['bandwidthLimit'], params['instructionMaxPrice'], params['bandwidthMaxPrice'], params['dockerBandwidthMaxPrice'], params['completionDeadline'], params['deposit'])
             self.job_offers[params['offerId']] = offer

         #sleep(max(next_polling - time(), 0))
        #after reading events call mathing
        matches = self.HopcroftKarp()
        if matches:
            print("MATCHES = " +str(matches))
            print(self.resource_providers)
            print(self.resource_offers)
            print(self.job_creators)
            print(self.job_offers)
        for i in matches:
            print("I: post match job offer = %s" %self.job_offers[i[0]].bandwidthMaxPrice)
            print("I: post match resource offer = %s" %self.resource_offers[i[1]].bandwidthPrice)

            print("jo id: %s" %self.job_offers[i[0]].offerId)
            print("ro id: %s" %self.resource_offers[i[1]].offerId)
            print(self.job_offers[i[0]].offerId, self.resource_offers[i[1]].offerId,i[2])
#remove matches from list
            self.job_offers.pop(i[0])
            self.resource_offers.pop(i[1])


print("\nCreating Solver")
s = Solver()


print("\nCreate Mediator")
#mediator = Mediator(1,1,1,1,1,1)
mediator = {'addr': 1, 'arch': 1, 'instructionPrice': 1, 'bandwidthPrice': 1, 'dockerBandwidthPrice': 1}
m ={'name': 'mediatorRegistered', 'params':mediator}
#print(m)
#print(m['name'])
#print(m['params'])
#print(m['params']['arch'])


s.run([m])
print(s.mediators)

print("\nCreate ResourceProvider")
#rp = ResourceProvider(1,1,mediator)
rp = {'addr': 1, 'arch': 1, 'timePerInstruction': 1}
rp2 = {'name': 'resourceProviderRegistered', 'params': rp}
s.run([rp2])
print(s.resource_providers)
#exit(1)
#rp.supportedDirectories = [1,2,3]

print("\nCreate JobCreator")
#jc = JobCreator(mediator)
jc = {'addr': 1}
jc = {'name': 'jobCreatorRegistered', 'params': jc}
s.run([jc])
#print(s.job_creators)


print("\nCreate JobOffer")
#def __init__(self, offerId, jobCreator, size, arch, instructionLimit, ramLimit, localStorageLimit, bandwidthLimit, instructionMaxPrice, bandwidthMaxPrice, dockerBandwidthMaxPrice, completionDeadline):
joClassPass = JobOffer(1,1,1,1,1,1,1,1,1,1,1,datetime.datetime.now()+datetime.timedelta(100,0,0), 300)
joClassFail = JobOffer(1,1,1,1,1,1,1,1,1,1,1,datetime.datetime.now()-datetime.timedelta(100,10,10), 300)
jo  = {'offerId': 0, 'jobCreator': 1, 'size': 1, 'arch': 1, 'instructionLimit': 1, 'ramLimit': 1, 'localStorageLimit': 1, 'bandwidthLimit': 1, 'instructionMaxPrice': 5, 'bandwidthMaxPrice': 5, 'dockerBandwidthMaxPrice': 4, 'completionDeadline': datetime.datetime.now()+datetime.timedelta(100,0,0), 'addr': 1, 'deposit': 300}
jo1  = {'offerId': 1, 'jobCreator': 1, 'size': 1, 'arch': 1, 'instructionLimit': 1, 'ramLimit': 1, 'localStorageLimit': 1, 'bandwidthLimit': 1, 'instructionMaxPrice': 5, 'bandwidthMaxPrice': 5, 'dockerBandwidthMaxPrice': 4, 'completionDeadline': datetime.datetime.now()+datetime.timedelta(100,0,0), 'addr': 1, 'deposit': 300}
jo2 = {'offerId': 3, 'jobCreator': 1, 'size': 1, 'arch': 1, 'instructionLimit': 1, 'ramLimit': 1, 'localStorageLimit': 1, 'bandwidthLimit': 1, 'instructionMaxPrice': 5, 'bandwidthMaxPrice': 5, 'dockerBandwidthMaxPrice': 4, 'completionDeadline': datetime.datetime.now()+datetime.timedelta(100,0,0), 'addr': 1, 'deposit': 300}

#new ones
#jo1  = {'offerId': 2, 'jobCreator': 1, 'size': 1,  'arch': 1, 'instructionLimit': 1, 'ramLimit': 1, 'localStorageLimit': 2, 'bandwidthLimit': 1, 'instructionMaxPrice': 2, 'bandwidthMaxPrice': 5, 'dockerBandwidthMaxPrice': 4,  'completionDeadline': datetime.datetime.now()+datetime.timedelta(100,0,0), 'addr': 1}
#jo2  = {'offerId': 3, 'jobCreator': 1, 'size': 1,  'arch': 1, 'instructionLimit': 1, 'ramLimit': 1, 'localStorageLimit': 3, 'bandwidthLimit': 1, 'instructionMaxPrice': 5, 'bandwidthMaxPrice': 2, 'dockerBandwidthMaxPrice': 2,  'completionDeadline': datetime.datetime.now()+datetime.timedelta(100,0,0), 'addr': 2}

print("\nCreate ResourceOffer")
roClass = ResourceOffer(1,1,1,1,1,1,1,1,1,1, 300)
ro = {'offerId': 0, 'resourceProvider': 1, 'instructionPrice': 1, 'instructionCap': 3, 'memoryCap': 3, 'localStorageCap': 3, 'bandwidthCap': 3, 'bandwidthPrice': 4, 'dockerBandwidthCap': 3, 'dockerBandwidthPrice': 3, 'addr': 1, 'deposit': 300}
ro1 = {'offerId': 1, 'resourceProvider': 1, 'instructionPrice': 3, 'instructionCap': 3, 'memoryCap': 3, 'localStorageCap': 3, 'bandwidthCap': 3, 'bandwidthPrice': 4, 'dockerBandwidthCap': 3, 'dockerBandwidthPrice': 3, 'addr': 1,'deposit': 300}
ro2 = {'offerId': 2, 'resourceProvider': 1, 'instructionPrice': 3, 'instructionCap': 3, 'memoryCap': 3, 'localStorageCap': 3, 'bandwidthCap': 3, 'bandwidthPrice': 2, 'dockerBandwidthCap': 3, 'dockerBandwidthPrice': 2, 'addr': 1, 'deposit': 300}

#ro matches with [jo,jo1,jo2]
#ro1 matches with [jo]
#ro2 matches with [jo2]

print("\nAdd TrustedMediator")
tM = []
jm  = {'addr': 1, 'mediator': 1}
jm2 = {'name': 'JobCreatorAddedTrustedMediator', 'params': jm}

rm = {'addr': 1, 'mediator': 1}
rm2 = {'name': 'ResourceProviderAddedTrustedMediator', 'params': rm}

s.run([rm2,jm2])

print("\nMatching")
print("Should match = True")
print(s.matchable(roClass,joClassPass))

print("Should match = Fail")
print(s.matchable(roClass,joClassFail))


print("\nPopulating offer events")
#offers = [{'name': 'jobOfferPosted', 'params': jo}, {'name': 'jobOfferPosted', 'params': jo1},  {'name': 'jobOfferPosted', 'params': jo2}, {'name': 'resourceOfferPosted', 'params': ro}, {'name': 'resourceOfferPosted', 'params': ro1}, {'name': 'resourceOfferPosted', 'params': ro2}]
#only r0
offers = [{'name': 'jobOfferPosted', 'params': jo}, {'name': 'jobOfferPosted', 'params': jo1},  {'name': 'jobOfferPosted', 'params': jo2}, {'name': 'resourceOfferPosted', 'params': ro}]

print("\nContents of offer events")
print(offers)


print("\nRunning Solver.run(offers)")
s.run(offers)
print("Solver job offers: " + str(s.job_offers))
print("Solver resource offers: " + str(s.resource_offers))
