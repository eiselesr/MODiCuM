import unittest
import zmq
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.PlatformClient as PlatformClient

class TestCase(unittest.TestCase):
    def setUp(self):
        self.host = cfg.DIR_IP
        self.port = cfg.DIR_PORT
        self.sftport = private.port #port for sftp transfer, e.g. 222
        self.jcID = "user_4"
        self.rpID = "user_5"
        self.job = "matrix_multiplication"
        self.localpath = cfg.WORKPATH
        self.sshpath = "/home/riaps/.ssh/cluster_2018_9_10"
        self.pubkey = private.pubkey

    def test_init(self):
        PC = PlatformClient.PlatformClient()
        PC.DC.test()


    def test_simulateJC(self):
        PC = PlatformClient.PlatformClient()
        PC.active = True
        PC.simulate(eventport="7777")

    def test_simulateRP(self):
        PC = PlatformClient.PlatformClient()
        PC.active = True
        PC.simulate(eventport="7778")

    def test_event(self):
        self.ctxt = zmq.Context()
        jceventSender = self.ctxt.socket(zmq.REQ)
        jceventSender.connect("tcp://%s:%s" %("localhost","7777"))
        rpeventSender = self.ctxt.socket(zmq.REQ)
        rpeventSender.connect("tcp://%s:%s" %("localhost","7778"))
        direventSender =self.ctxt.socket(zmq.REQ)
        direventSender.connect("tcp://%s:%s" %("localhost","5555"))


        msg = {
            "request": "publish",
            "host" : self.host,
            "port" : self.port,
            "jcID" : self.jcID,
            "rpID" : self.rpID,
            "job" : self.job,
            "pubkey" : self.pubkey,
            "sftport" : self.sftport,
            "localpath" : self.localpath,
            "sshpath" : self.sshpath
        }
        jceventSender.send_pyobj(msg)
        response = jceventSender.recv_pyobj()
        print("event listener response: %s" %response)

        msg["request"] = "getJob"
        msg["input"] = cfg.WORKPATH+"/"+self.job+"/input"
        msg["output"] = cfg.WORKPATH+"/"+self.job+"/output"
        msg["appinput"] = "/app/input"
        msg["appoutput"] = "/app/output"
        msg["perf_enabled"] = True


        rpeventSender.send_pyobj(msg)
        response = rpeventSender.recv_pyobj()
        print("event listener response: %s" %response)


        msg["request"] = "getResult"
        jceventSender.send_pyobj(msg)
        response = jceventSender.recv_pyobj()
        print("event listener response: %s" %response)

        msg = {
            'request': "stop"
        }
        jceventSender.send_pyobj(msg)
        response = jceventSender.recv_pyobj()
        print("event listener response: %s" %response)
        rpeventSender.send_pyobj(msg)
        response = rpeventSender.recv_pyobj()
        print("event listener response: %s" %response)
        direventSender.send_pyobj(msg)
        response = direventSender.recv_pyobj()
        print("event listener response: %s" %response)

        # jceventSender.close()
        # rpeventSender.close()
        # direventSender.close()
        # self.ctxt.term()
        # self.ctxt.destroy()
