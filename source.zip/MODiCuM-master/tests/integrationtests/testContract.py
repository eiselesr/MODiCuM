import unittest
import pprint
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.Contract.Contract as Contract
import src.python.MODiCuM.EthereumClient as EthereumClient

class TestCase(unittest.TestCase):
    def setUp(self):
        self.ip = cfg.GETH_IP
        self.port = cfg.GETH_PORT

    def test_generate_topics(self):
        fromContract = "0x8a36f5a234186d446e36a7df36ace663a05a580d9bea2dd899c6dd76a075d5fa"
        fromKek = "0xaed042a05fd6a4cf033a4ae8625d41a4a49b4836007d49da90d422528eb101d7"
        events = {
			"Debug" : [("value", "uint")],
            "DebugArch" : [("arch", "uint8")],
            "DebugUint" : [("value", "uint256")],
		}
        ethclient = EthereumClient.EthereumClient(self.ip, self.port)
        C=Contract.Contract(client=ethclient, address=None, events=events)
        topics = C.generate_topics(events)
        pprint.pprint(topics)
        print(fromContract)
        print(fromKek)

        ethclient.exit()
