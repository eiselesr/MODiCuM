import os
import time
import unittest
import zmq
import hashlib
import tarfile
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.Directory as Directory
import src.python.MODiCuM.ContractManager as ContractManager
import src.python.MODiCuM.JobCreator as JobCreator
import src.python.MODiCuM.ResourceProvider as ResourceProvider
import src.python.MODiCuM.Mediator as Mediator
import src.python.MODiCuM.Solver as Solver
# import src.python.MODiCuM.Directory as Directory



class TestCase(unittest.TestCase):
    def setUp(self):
        self.host = "129.59.105.24"
        self.port = cfg.DIR_PORT
        self.sftport = private.port
        self.jcID = "user_4"
        self.rpID = "user_5"
        self.job = "matrix_multiplication"
        self.localpath = cfg.WORKPATH
        self.sshpath = "/home/riaps/.ssh/cluster_2018_9_10"
        self.pubkey = private.pubkey

    def test_init(self):
        self.D = Directory.Directory()
        self.CM = ContractManager.ContractManager(cfg.MANA_IP)
        self.JC = JobCreator.JobCreator()
        self.RP = ResourceProvider.ResourceProvider()
        self.M = Mediator.Mediator()
        self.S = Solver.Solver()

        self.ctxt = zmq.Context()

    def test_simulate(self):
        RUN = False

        if RUN:
            self.test_init()
        #--------------------------------------------------------------
        # For interacting with the CLI
        #--------------------------------------------------------------
        if RUN:
            jceventSender = self.ctxt.socket(zmq.REQ)
            jceventSender.connect("tcp://%s:%s" %("localhost","7777"))
            rpeventSender = self.ctxt.socket(zmq.REQ)
            rpeventSender.connect("tcp://%s:%s" %("localhost","7778"))
            direventSender =self.ctxt.socket(zmq.REQ)
            direventSender.connect("tcp://%s:%s" %("localhost","5555"))

            print(os.getcwd())
        #--------------------------------------------------------------
        # Start Directory
        #--------------------------------------------------------------
        if RUN:
            self.D.startServer(port=cfg.DIR_PORT,childport=cfg.CHILD_PORT)
        #--------------------------------------------------------------
        # Start ContractManager
        #--------------------------------------------------------------
        if RUN:
            with open("src/solidity/output/Modicum.bin") as f:
                BYTECODE = "0x"+f.read()
                self.CM.run(cfg.GETH_IP, cfg.GETH_PORT,BYTECODE,cfg.TRANSACTION_GAS,verbose=False)

        #--------------------------------------------------------------
        # Start Solver
        #--------------------------------------------------------------
        if RUN:
            self.S.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
        # self.S.register(self.S.account)

        #--------------------------------------------------------------
        # Start Mediator
        #--------------------------------------------------------------
        if RUN:
            self.M.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
            self.M.register(self.M.account, "amd64", instructionPrice=1, bandwidthPrice=1, dockerBandwidthPrice=1)
            while self.M.addr is None:
                time.sleep(1)
            print("M.addr is : %s" %type(self.M.addr))

        #--------------------------------------------------------------
        # Start JobCreator
        #--------------------------------------------------------------

        self.JC = JobCreator.JobCreator()
        dockerClient = self.JC.DW.getDockerClient()
        image = self.JC.DW.buildImage(dockerClient, cfg.jobPath, cfg.tag)
        tag = image.tags[0]
        self.JC.DW.saveImage(cfg.jobPath+"/image/"+tag+".tar", image)
        jobHash = image.id.split(":")[1] #strip off sha256 prefix
        print(jobHash)
        jobHash_int = int(jobHash, 16)
        print(jobHash_int)

        image_tarPath = cfg.imagePath+"/%s.tar" %tag
        print(tarfile.is_tarfile(image_tarPath))

        TF = tarfile.open(image_tarPath)
        # print(TF.getmembers())
        # print(TF.getnames())

        sha256_hash = hashlib.sha256()
        with open(image_tarPath, "rb") as f:
            for byte_block in iter(lambda: f.read(8192),b""):
                sha256_hash.update(byte_block)
            tarHash = sha256_hash.hexdigest()
        tarHash_int = int(tarHash, 16)
        print("tarHash: %s" %tarHash)
        print("tarHash_int: %s" %tarHash_int)

        job_size = os.path.getsize(image_tarPath)
        print("job_size: %s" %job_size)

        dockerAPIclient = self.JC.DW.getDockerAPIClient()
        digest = self.JC.DW.getImageDigest(dockerAPIclient, tag)

        byte_price = 1



        if RUN:
            self.JC.startCLIListener(cliport="7777")
            self.JC.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
            self.JC.register(self.JC.account)
            while self.JC.addr is None:
                time.sleep(1)
            self.JC.addMediator(self.JC.account, self.M.addr)
            jobHash = "b599cff993a602c14e6d45beab7a48c25e6753b7106cd6173488e843a7158060"
            jobHash_int = int(jobHash, 16)
            completionDeadline = int(round((time.time()+100)*1000))#in ms



            #---publish job-------------------------------------------------
            msg = {
                "request": "publish",
                "host" : self.host,
                "port" : self.port,
                "jcID" : self.jcID,
                "rpID" : self.rpID,
                "job" : self.job,
                "pubkey" : self.pubkey,
                "sftport" : self.sftport,
                "localpath" : self.localpath,
                "sshpath" : self.sshpath
            }
            jceventSender.send_pyobj(msg)
            response = jceventSender.recv_pyobj()
            print("cli listener response: %s" %response)

            # self.JC.postOffer(
            #     self.JC.account, tarHash_int, uri=self.job, size=job_size, arch=digest["arch"],
            #     instructionLimit=100, ramLimit=256,
            #     localStorageLimit=job_size, bandwidthLimit=2*job_size, instructionMaxPrice=2,
            #     bandwidthMaxPrice=10, dockerBandwidthMaxPrice=0,
            #     completionDeadline=completionDeadline)
            #---post job-------------------------------------------------
            self.JC.postOffer(
                self.JC.account, jobHash_int, uri=self.job, size=1, arch="amd64",
                instructionLimit=1, ramLimit=1,
                localStorageLimit=1, bandwidthLimit=1, instructionMaxPrice=1,
                bandwidthMaxPrice=1, dockerBandwidthMaxPrice=1,
                completionDeadline=completionDeadline)

        #--------------------------------------------------------------
        # Start Resource Provider
        #--------------------------------------------------------------
        if RUN:
            self.RP.startCLIListener(cliport="7778")
            self.RP.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
            self.RP.register(self.RP.account,arch='amd64', timePerInstruction=1)
            while self.RP.addr is None:
                time.sleep(1)
            self.RP.addMediator(self.RP.account, self.M.addr)
            # self.RP.postOffer(
            #     self.RP.account, instructionPrice=1, instructionCap=1000, memoryCap=512,
            #     localStorageCap=300000000, bandwidthCap=20,
            #     bandwidthPrice=1, dockerBandwidthCap=20, dockerBandwidthPrice=1)

            self.RP.postOffer(
                self.RP.account, instructionPrice=1, instructionCap=1, memoryCap=1,
                localStorageCap=1, bandwidthCap=1,
                bandwidthPrice=1, dockerBandwidthCap=1, dockerBandwidthPrice=1)
