import unittest
import src.python.MODiCuM.Contract
import importlib

class TestCase(unittest.TestCase):
    def setUp(self):
        pass

    @staticmethod
    def test_get_enum_by_classname(name):
        module = importlib.import_module('..Enums',__name__)
        logging.info(module)
        logging.info(name)
        logging.info(getattr(module, name))
        return getattr(module, name)
