import unittest
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.ResourceProvider as ResourceProvider


class TestCase(unittest.TestCase):
    def setUp(self):
        self.host = "129.59.105.24"
        self.port = cfg.DIR_PORT
        self.sftport = private.port
        self.jcID = "user_4"
        self.rpID = "user_5"
        self.job = "matrix_multiplication"
        self.localpath = cfg.WORKPATH
        self.sshpath = "/home/riaps/.ssh/cluster_2018_9_10"
        self.pubkey = private.pubkey

    def test_init(self):
        RP = ResourceProvider.ResourceProvider()
    def test_connect(self):
        RP = ResourceProvider.ResourceProvider()
        self.client, self.contract = RP.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
        print("client: %s" %self.client)
        print("contract: %s" %self.contract)
        RP.platformDisconnect()

    def test_register(self):
        RP = ResourceProvider.ResourceProvider()
        client, contract = RP.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
        print("client: %s" %client)
        print("contract: %s" %contract)
        RP.platformListenerThread.start()
        print("RP is listening")
        contract.registerResourceProvider(RP.account, arch="amd64", timePerInstruction=1)

        # RP.platformDisconnect()

    def test_eventListener(self):
        RP = ResourceProvider.ResourceProvider()
        client, contract = RP.platformConnect(cfg.MANA_IP, cfg.GETH_IP, cfg.GETH_PORT)
        print("client: %s" %client)
        print("contract: %s" %contract)
        RP.platformListenerThread.start()
        print("RP is listening")
        # contract.check(RP.account,Enums.Architecture.armv7)
        contract.check(RP.account,"armv7")
        contract.check(RP.account,"amd64")
