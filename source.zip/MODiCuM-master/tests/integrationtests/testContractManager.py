import unittest
import time
import src.config_main as cfg
import src.config_private as private

import src.python.MODiCuM.ContractManager as ContractManager

class TestCase(unittest.TestCase):
    def setUp(self):
        self.host = "129.59.105.24"
        self.port = cfg.DIR_PORT
        self.sftport = private.port
        self.geth_ip = cfg.GETH_IP
        self.geth_port = cfg.GETH_PORT
        self.jcID = "user_4"
        self.rpID = "user_5"
        self.job = "matrix_multiplication"
        self.localpath = cfg.WORKPATH
        self.sshpath = "/home/riaps/.ssh/cluster_2018_9_10"
        self.pubkey = private.pubkey

    def test_init(self):
        CM = ContractManager.ContractManager(cfg.MANA_IP)

    def test_getAccount(self):
        CM = ContractManager.ContractManager(cfg.MANA_IP)
        CM.startEthClient(self.geth_ip,self.geth_port)
        connected = False
        while not connected:
            response = CM.getEthAccount()
            if "ERROR" not in response:
                connected = True
        print("Account address is : %s" %response)
        CM.ethlient.exit()

    def test_deployContract(self):
        with open("/home/riaps/projects/MODiCuM/src/solidity/output/Modicum.bin") as f:
            BYTECODE = "0x"+f.read()
            # print(BYTECODE)

            CM = ContractManager.ContractManager(cfg.MANA_IP)
            CM.startEthClient(self.geth_ip,self.geth_port)
            connected = False
            while not connected:
                response = CM.getEthAccount()
                if "ERROR" not in response:
                    connected = True
            print("Account address is : %s" %response)
            print(CM.account)
            # CM.ethlient.exit() # Why does running this here not seem to cause problems?


            contract_address = CM.deploy_contract(BYTECODE,cfg.TRANSACTION_GAS,verbose=True)
            print ("contract address is : %s" %contract_address)
            CM.ethlient.exit()

    def test_pollClients(self):
        with open("/home/riaps/projects/MODiCuM/src/solidity/output/Modicum.bin") as f:
            BYTECODE = "0x"+f.read()
            # print(BYTECODE)

            CM = ContractManager.ContractManager(cfg.MANA_IP)
            CM.startEthClient(self.geth_ip,self.geth_port)
            connected = False
            while not connected:
                response = CM.getEthAccount()
                if "ERROR" not in response:
                    connected = True
            print("Account address is : %s" %response)
            print(CM.account)
            # CM.ethlient.exit() # Why does running this here not seem to cause problems?
            contract_address = CM.deploy_contract(BYTECODE,cfg.TRANSACTION_GAS,verbose=True)
            print ("contract address is : %s" %contract_address)
            CM.listenerThread.start()
            time.sleep(5)
            CM.stop()

    def test_run(self):
        with open("/home/riaps/projects/MODiCuM/src/solidity/output/Modicum.bin") as f:
            BYTECODE = "0x"+f.read()
            CM = ContractManager.ContractManager(cfg.MANA_IP)
            CM.run(cfg.GETH_IP, cfg.GETH_PORT,BYTECODE,cfg.TRANSACTION_GAS,verbose=False)
