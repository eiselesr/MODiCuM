#python script to generate the actual job of 500 x 500 multiplication.
#Here the hash of the matrix multiplication result is stored in mongodb.
#Using Hashlib to produce sha256 of the matrix resultant

import time
import logging
import hashlib
import numpy
import json
import functools
import os
import pathlib

input=os.environ['MODICUM_INPUT']
print(input)
output=os.environ['MODICUM_OUTPUT']
print(output)

def hashResult(matrix):
	mylist=hashlib.sha256(str(matrix).encode())
	hex_dig = mylist.hexdigest()

def randMats():
	matrices = {}

	# for root, dirs, files in os.walk(input):
	#     for filename in files:
	#         with open(filename) as f:

	with open ("%s/myInput.json" %(input) ) as f:
		matricesParams = json.load(f)
		for A in matricesParams:
			m=matricesParams[A]['m']
			n=matricesParams[A]['n']
			# matrix = numpy.ones((m,n))
			matrix = numpy.random.randint(low=0,high=5,size=(m,n))
			matrices[A] = matrix
	return matrices

def fout(result):
	pathlib.Path(output).mkdir(parents=True, exist_ok=True)
	with open("%s/myOutput.json" %(output), "w") as f:
		# result.tofile(f,sep="\n")
		# print(type(result))
		# print(type(result[0][0]))
		# numpy.savetxt(f, result, fmt='%d')
		# f.write('This is a test\n')
		f.write(str(result))


matrices = randMats()
product = functools.reduce(numpy.matmul,matrices.values())
print(product)
fout(product)
