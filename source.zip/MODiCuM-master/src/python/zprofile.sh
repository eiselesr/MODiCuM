
influx -execute 'drop database cadvisor'
influx -execute 'create database cadvisor'

fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput2.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"cd /home/riaps/projects/MODiCuM/src/python; sudo modicum run --profiler True"

./zinflux.sh
