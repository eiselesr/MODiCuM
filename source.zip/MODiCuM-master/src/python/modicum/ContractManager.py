import zmq
import logging
import sys
import os
import dotenv
from time import time, sleep
from threading import Thread
from .EthereumClient import EthereumClient
from .Contract.ModicumContract import ModicumContract

import pprint


class ContractManager:
    def __init__(self, manager_ip):
        self.logger = logging.getLogger("ContractManager")
        self.logger.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        # formatter = logging.Formatter("---%(name)s---:%(message)s\n\r")
        formatter = logging.Formatter("---%(name)s---:%(message)s")
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.manager_ip = manager_ip
        super(ContractManager, self).__init__()
        self.listenerThread = Thread(target=self.pollClients)

    def startEthClient(self,ip,port):
        self.ethclient = EthereumClient(ip=ip, port=port)
        self.logger.info("client: %s" %self.ethclient)

    def getEthAccount(self,index):
        response = self.ethclient.accounts()
        self.logger.debug("ethclient accounts: %s" %response)
        if "ERROR" not in response:
          self.account = response[index] # use the first owned address
          return self.account
        else:
          return "ERROR: Failed to fetch account"


    def pollClients(self):
        self.logger.info("Entering main function...")
        self.ctxt = zmq.Context()
        self.zmqclient = self.ctxt.socket(zmq.REP)
        self.zmqclient.bind("tcp://%s:10001" %self.manager_ip)
        self.poller = zmq.Poller()
        self.poller.register(self.zmqclient, zmq.POLLIN)
        # epoch = time() - START_INTERVAL * INTERVAL_LENGTH
        epoch = time()
        self.logger.info("Listening for clients...")
        self.listening = True
        while self.listening:
            socks = dict(self.poller.poll(1000))
            # self.logger.info("Polling")
            if self.zmqclient in socks and socks[self.zmqclient]:
                msg = self.zmqclient.recv_pyobj()
                if msg['request'] == "query_contract_address":
                    self.logger.info("query_contract_address()")
                    self.zmqclient.send_pyobj({'contract': self.contract_address, 'time': time() - epoch})
                    self.logger.info("contract_address sent")

                elif msg['request'] == "stop":
                    self.zmqclient.send_pyobj("Contract Manager Stopping")
                    self.stop()
                else:
                    self.logger.error("Unknown request: " + msg['request'])
                    self.zmqclient.send_pyobj("Unknown request!")

    def stop(self):
        self.logger.info("Stop Contract Manager")
        self.listening = False
        self.ethclient.exit()
        # self.listenerThread.join()

    def deploy_contract(self,BYTECODE,TRANSACTION_GAS,verbose=False):
        self.logger.info("Y: Deploying contract...")

        receiptID = None
        while True:
          if not receiptID:
              self.logger.info("submit contract")
              receiptID = self.ethclient.command("eth_sendTransaction", params=[{'data': BYTECODE, 'from': self.account, 'gas': TRANSACTION_GAS}], verbose=verbose)
              self.logger.info("Transaction receipt: " + receiptID)
          else:
              sleep(5)
              self.logger.info("Waiting for contract to be mined... (block number: {})".format(self.ethclient.command("eth_blockNumber", params=[])))
              receipt = self.ethclient.command("eth_getTransactionReceipt", params=[receiptID])
              self.logger.debug("receipt:%s" %receipt)
              if receipt is not None and "ERROR" not in receipt:
                  self.contract_address = receipt['contractAddress']
                  break
        self.contract = ModicumContract(self.ethclient, self.contract_address)
        self.logger.info("Contract address: " + self.contract_address)

        ### Updating environment ###
        reactionDeadline = int(os.getenv('ReactionDeadline', '86400'))
        penaltyRate = int(os.getenv('PenaltyRate', '64'))
        self.logger.info(f'Updating ReactionDeadline to {reactionDeadline}')
        self.contract.setReactionDeadline(self.account, reactionDeadline)
        self.logger.info(f'Updating penaltyRate to {penaltyRate}')
        self.contract.setPenaltyRate(self.account, penaltyRate)
        ### Done ###

        self.logger.info("Y: Contract Submitted")
        return self.contract_address

    def run(self,geth_ip,geth_port,BYTECODE,TRANSACTION_GAS,verbose,index):
        path = dotenv.find_dotenv('.env', usecwd=True)
        dotenv.load_dotenv(path)
        self.startEthClient(geth_ip,geth_port)
        self.logger.info("try to connect")
        connected = False
        while not connected:
            response = self.getEthAccount(index)
            self.logger.info(response)
            if "ERROR" not in response:
                connected = True
            sleep(1)
        self.logger.info("Account address is : %s" %response)
        self.deploy_contract(BYTECODE,TRANSACTION_GAS,verbose)
        self.listenerThread.start()
