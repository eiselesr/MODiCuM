from .Contract import Contract
from .Enums import *


class ModicumContract(Contract):

	def check(self, from_account, arch):
		return self.call_func(from_account, 0, "check", 
			"Architecture", arch
		)

	def setPenaltyRate(self, from_account, _penaltyRate):
		return self.call_func(from_account, 0, "setPenaltyRate", 
			"uint256", _penaltyRate
		)

	def setReactionDeadline(self, from_account, _reactionDeadline):
		return self.call_func(from_account, 0, "setReactionDeadline", 
			"uint256", _reactionDeadline
		)

	def registerMediator(self, from_account, arch, instructionPrice, bandwidthPrice, dockerBandwidthPrice):
		return self.call_func(from_account, 0, "registerMediator", 
			"Architecture", arch,
			"uint256", instructionPrice,
			"uint256", bandwidthPrice,
			"uint256", dockerBandwidthPrice
		)

	def mediatorAddTrustedDirectory(self, from_account, directory):
		return self.call_func(from_account, 0, "mediatorAddTrustedDirectory", 
			"address", directory
		)

	def getMediatorTrustedDirectories(self, from_account, mediator):
		return self.call_func(from_account, 0, "getMediatorTrustedDirectories", 
			"address", mediator
		)

	def registerResourceProvider(self, from_account, arch, timePerInstruction):
		return self.call_func(from_account, 0, "registerResourceProvider", 
			"Architecture", arch,
			"uint256", timePerInstruction
		)

	def resourceProviderAddTrustedMediator(self, from_account, mediator):
		return self.call_func(from_account, 0, "resourceProviderAddTrustedMediator", 
			"address", mediator
		)

	def resourceProviderAddTrustedDirectory(self, from_account, directory):
		return self.call_func(from_account, 0, "resourceProviderAddTrustedDirectory", 
			"address", directory
		)

	def getResourceProviderTrustedMediators(self, from_account, rp):
		return self.call_func(from_account, 0, "getResourceProviderTrustedMediators", 
			"address", rp
		)

	def getResourceProviderTrustedDirectories(self, from_account, rp):
		return self.call_func(from_account, 0, "getResourceProviderTrustedDirectories", 
			"address", rp
		)

	def registerJobCreator(self, from_account):
		return self.call_func(from_account, 0, "registerJobCreator"
			
		)

	def getJobCreatorTrustedMediators(self, from_account, jc):
		return self.call_func(from_account, 0, "getJobCreatorTrustedMediators", 
			"address", jc
		)

	def jobCreatorAddTrustedMediator(self, from_account, mediator):
		return self.call_func(from_account, 0, "jobCreatorAddTrustedMediator", 
			"address", mediator
		)

	def postResOffer(self, from_account, price, instructionPrice, instructionCap, memoryCap, localStorageCap, bandwidthCap, bandwidthPrice):
		return self.call_func(from_account, price, "postResOffer", 
			"uint256", instructionPrice,
			"uint256", instructionCap,
			"uint256", memoryCap,
			"uint256", localStorageCap,
			"uint256", bandwidthCap,
			"uint256", bandwidthPrice
		)

	def postJobOffer(self, from_account, price, jobHash, uri, directory, size, arch, instructionLimit, ramLimit, localStorageLimit, instructionMaxPrice, bandwidthMaxPrice, completionDeadline):
		return self.call_func(from_account, price, "postJobOffer", 
			"uint256", jobHash,
			"bytes32", uri,
			"address", directory,
			"uint256", size,
			"Architecture", arch,
			"uint256", instructionLimit,
			"uint256", ramLimit,
			"uint256", localStorageLimit,
			"uint256", instructionMaxPrice,
			"uint256", bandwidthMaxPrice,
			"uint256", completionDeadline
		)

	def cancelJobOffer(self, from_account, offerId):
		return self.call_func(from_account, 0, "cancelJobOffer", 
			"uint256", offerId
		)

	def cancelResOffer(self, from_account, offerId):
		return self.call_func(from_account, 0, "cancelResOffer", 
			"uint256", offerId
		)

	def postMatch(self, from_account, jobOfferId, resourceOfferId, mediator):
		return self.call_func(from_account, 0, "postMatch", 
			"uint256", jobOfferId,
			"uint256", resourceOfferId,
			"address", mediator
		)

	def postResult(self, from_account, matchId, status, uri, hash, instructionCount, bandwidthUsage, dockerBandwidthUsage):
		return self.call_func(from_account, 0, "postResult", 
			"uint256", matchId,
			"ResultStatus", status,
			"bytes32", uri,
			"uint256", hash,
			"uint256", instructionCount,
			"uint256", bandwidthUsage,
			"uint256", dockerBandwidthUsage
		)

	def rejectResult(self, from_account, resultId):
		return self.call_func(from_account, 0, "rejectResult", 
			"uint256", resultId
		)

	def acceptResult(self, from_account, resultId):
		return self.call_func(from_account, 0, "acceptResult", 
			"uint256", resultId
		)

	def postMediationResult(self, from_account, matchId, status, uri, hash, instructionCount, bandwidthUsage, dockerBandwidthUsage, verdict, faultyParty):
		return self.call_func(from_account, 0, "postMediationResult", 
			"uint256", matchId,
			"ResultStatus", status,
			"bytes32", uri,
			"uint256", hash,
			"uint256", instructionCount,
			"uint256", bandwidthUsage,
			"uint256", dockerBandwidthUsage,
			"Verdict", verdict,
			"Party", faultyParty
		)

	def punish(self, from_account, matchId, faultyParty, extraCost):
		return self.call_func(from_account, 0, "punish", 
			"uint256", matchId,
			"Party", faultyParty,
			"uint256", extraCost
		)

	def close(self, from_account, matchId):
		return self.call_func(from_account, 0, "close", 
			"uint256", matchId
		)

	def timeout(self, from_account, matchId):
		return self.call_func(from_account, 0, "timeout", 
			"uint256", matchId
		)

	def __init__(self, client, address):
		super().__init__(client, address, {'Debug': [('value', 'uint64')], 'DebugArch': [('arch', 'Architecture')], 'DebugUint': [('value', 'uint256')], 'DebugString': [('str', 'bytes32')], 'penaltyRateSet': [('penaltyRate', 'uint256')], 'reactionDeadlineSet': [('reactionDeadline', 'uint256')], 'ResultReaction': [('resultId', 'uint256'), ('matchId', 'uint256'), ('ResultReaction', 'uint256')], 'ResultPosted': [('resultId', 'uint256'), ('matchId', 'uint256'), ('status', 'ResultStatus'), ('uri', 'bytes32'), ('hash', 'uint256'), ('instructionCount', 'uint256'), ('bandwidthUsage', 'uint256'), ('dockerBandwidthUsage', 'uint256')], 'Matched': [('matchId', 'uint256'), ('jobOfferId', 'uint256'), ('resourceOfferId', 'uint256'), ('mediator', 'address')], 'JobOfferPosted': [('offerId', 'uint256'), ('jobCreator', 'address'), ('size', 'uint256'), ('arch', 'Architecture'), ('instructionLimit', 'uint256'), ('ramLimit', 'uint256'), ('localStorageLimit', 'uint256'), ('bandwidthLimit', 'uint256'), ('instructionMaxPrice', 'uint256'), ('bandwidthMaxPrice', 'uint256'), ('dockerBandwidthMaxPrice', 'uint256'), ('completionDeadline', 'uint256'), ('deposit', 'uint256')], 'JobOfferImagePosted': [('offerId', 'uint256'), ('hash', 'uint256'), ('uri', 'bytes32'), ('directory', 'address')], 'ResourceOfferPosted': [('offerId', 'uint256'), ('resourceProvider', 'address'), ('instructionPrice', 'uint256'), ('instructionCap', 'uint256'), ('memoryCap', 'uint256'), ('localStorageCap', 'uint256'), ('bandwidthCap', 'uint256'), ('bandwidthPrice', 'uint256'), ('dockerBandwidthCap', 'uint256'), ('dockerBandwidthPrice', 'uint256'), ('deposit', 'uint256')], 'JobOfferCanceled': [('offerId', 'uint256')], 'ResourceOfferCanceled': [('resOfferId', 'uint256')], 'JobAssignedForMediation': [('matchId', 'uint256')], 'MediatorRegistered': [('addr', 'address'), ('arch', 'Architecture'), ('instructionPrice', 'uint256'), ('bandwidthPrice', 'uint256'), ('dockerBandwidthPrice', 'uint256')], 'GotMediator': [('addr', 'address'), ('mediator', 'address')], 'ResourceProviderRegistered': [('addr', 'address'), ('arch', 'Architecture'), ('timePerInstruction', 'uint256')], 'ResourceProviderAddedTrustedMediator': [('addr', 'address'), ('mediator', 'address')], 'JobCreatorRegistered': [('addr', 'address')], 'JobCreatorAddedTrustedMediator': [('addr', 'address'), ('mediator', 'address')], 'MediatorAddedTrustedDirectory': [('addr', 'address'), ('directory', 'address')], 'ResourceProviderAddedTrustedDirectory': [('addr', 'address'), ('directory', 'address')], 'MediationResultPosted': [('result', 'uint256'), ('faultyParty', 'Party'), ('verdict', 'Verdict'), ('matchId', 'uint256'), ('status', 'ResultStatus'), ('uri', 'bytes32'), ('hash', 'uint256'), ('instructionCount', 'uint256'), ('bandwidthUsage', 'uint256'), ('dockerBandwidthUsage', 'uint256'), ('mediationCost', 'uint256')], 'MatchClosed': [('matchId', 'uint256'), ('cost', 'uint256')], 'EtherTransferred': [('_from', 'address'), ('to', 'address'), ('value', 'uint256'), ('cause', 'EtherTransferCause')]})
