#import zmq
import logging
import sys
import os
import time
import datetime
from .PlatformClient import PlatformClient
from . import PlatformStructs as Pstruct

POLLING_INTERVAL = 1 # seconds



class Solver(PlatformClient):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger("Solver")
        self.logger.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        # formatter = logging.Formatter("---%(name)s---: \n%(message)s\n\r")
        formatter = logging.Formatter("---%(name)s---:%(message)s")
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.solve = False

        self.mediators = {}
        self.resource_providers = {}
        self.job_creators = {}
        self.resource_offers = {}
        self.job_offers = {}


    def register(self, account):
        self.account = account
        self.contract.registerSolver(account)


    def matchable(self, resource_offer, job_offer):
        #instructionCap >= instructionLimit
        #print("Begin Matching")
        if resource_offer.instructionCap < job_offer.instructionLimit:
            self.logger.info("Too many instructions")
            return(False, False)

        #localStorageCap>= localStorageLimit
        if resource_offer.localStorageCap < job_offer.localStorageLimit:
            self.logger.info("Too much disk")
            return(False, False)
        #bandwidthCap >= bandwidthLimit
        if resource_offer.bandwidthCap < job_offer.bandwidthLimit:
            self.logger.info("Too much data")
            return(False, False)
        #instructionPrice >= instructionMaxPrice
        if resource_offer.instructionPrice > job_offer.instructionMaxPrice:
            self.logger.info("Instructions too expensive")
            return(False, False)
        #bandwidthPrice >= bandwidthMaxPrice
        if resource_offer.bandwidthPrice > job_offer.bandwidthMaxPrice:
            self.logger.info("Data too expensive")
            return(False, False)

        # if (datetime.datetime.now() + datetime.timedelta(0,0,self.resource_providers[resource_offer.resourceProvider].timePerInstruction  * job_offer.instructionLimit)) > job_offer.completionDeadline:
        if (time.time() +
            job_offer.instructionLimit *
            self.resource_providers[resource_offer.resourceProvider].timePerInstruction
            ) > job_offer.completionDeadline:

            self.logger.info("Not Enough Time to complete")
            return(False, False)

        #JO.arch = RP.arch
        if self.resource_providers[resource_offer.resourceProvider].arch != job_offer.arch:
            self.logger.info("Architecture mismatch")
            return(False, False)




        # JO.trustedMediators = RP.trustedMediators
        for i in self.resource_providers[resource_offer.resourceProvider].trustedMediators:
            for j in self.job_creators[job_offer.jobCreator].trustedMediators:
                if i == j:
                    #Deposits >=jobDeposit
                    sharedMediator = self.mediators[i]
                    #necessary price of mediation by mediation
                    mediatorDeposit = job_offer.instructionLimit * sharedMediator.instructionPrice + job_offer.bandwidthLimit * sharedMediator.bandwidthPrice + job_offer.size * sharedMediator.dockerBandwidthPrice
                    #necessary price of job execution by resource_offer
                    jobDeposit = job_offer.instructionLimit * resource_offer.instructionPrice + job_offer.bandwidthLimit * resource_offer.bandwidthPrice + job_offer.size * resource_offer.dockerBandwidthPrice
                    #Assume that Fine is 10xprice
                    fineRate = 100 #TODO make finerate global constant
                    fine = fineRate * jobDeposit

                    # if ((resource_offer.deposit > (fine + mediatorDeposit)) and (job_offer.deposit > (fine + mediatorDeposit)) ):
                    return(True,i)
                    
        self.logger.info("No Mediator") #only will reach here if there is no mediator
        self.logger.info(self.resource_providers[resource_offer.resourceProvider].trustedMediators)
        self.logger.info(self.job_creators[job_offer.jobCreator].trustedMediators)


        return(False, False)

    def bfs(self, resourceList, jobList, edgeList, currentNode, jobsVisited, resourcesVisited, resourceOrJob, prevTraversedJob, prevTraversedResource):
        #Start searching all connected nodes
        if (resourceOrJob == 'resource'):
            #prevTraversedResource.append(currentNode)
            for i in resourceList[currentNode]:
               #if i not in prevTraversedJob:
                if jobsVisited[i] == 0: #i is not visited, free nodes
                    edgeList.append([i,currentNode])
                    return(True, edgeList)
            #recursively search if not found
            for i in resourceList[currentNode]:
                if i not in prevTraversedJob:
                    edgeList2 = edgeList
                    prevTraversedJob2 = prevTraversedResource
                    prevTraversedJob2.append(i)
                    edgeList2.append([i,currentNode])
                    [found, edgeList3] = self.bfs(resourceList, jobList,edgeList2, i, jobsVisited, resourcesVisited, 'job', prevTraversedJob2, prevTraversedResource)
                    if found: #if found == True
                        return(found,edgeList3)

        elif resourceOrJob == 'job':
            #prevTraversedJob.append(currentNode)
            for i in jobList[currentNode]:
                #if i not in prevTraversedResource:
                if resourcesVisited[i] == 0: #i is not visited, free node
                    edgeList.append([currentNode,i])
                    return(True, edgeList)
            #recursively search if not found
            for i in jobList[currentNode]:
                if i not in prevTraversedResource:
                    edgeList2 = edgeList
                    prevTraversedResource2 = prevTraversedResource
                    prevTraversedResource2.append(i)
                    edgeList2.append([currentNode,i])
                    [found, edgeList3 ] = self.bfs(resourceList, jobList,edgeList2, i, jobsVisited, resourcesVisited, 'resource', prevTraversedJob, prevTraversedResource2)
                    if found: #if found == True
                        return(found, edgeList3)

        return(False, [])

    def GreedyMatches(self):
        ros = list(self.resource_offers.keys())
        jos = list(self.job_offers.keys())
        matches = []
        for jo in jos:
            for ro in ros:
                (match, mediator) = self.matchable(self.resource_offers[ro], self.job_offers[jo])
                if match:
                    matches.append((jo, ro, mediator))
                    ros.remove(ro)
                    break
        return matches

        #maximum bipartate matching algorithm
    def HopcroftKarp(self):
        #Create graph
        jobList={}
        resourceList = {}
        mediatorList = {}

        edges = []
        #list of visited nodes
        visitedJob = {}
        visitedResource = {}
        for j in self.resource_offers:
            resourceList[j]=[]
            visitedResource[j]=0

        #create edges for each node
        for i in self.job_offers:
            edges = []
            visitedJob[i]=0
            mediatorList[i] = {}
            for j in self.resource_offers:
                [result,mediator] = self.matchable(self.resource_offers[j],self.job_offers[i])
                if (result):
                    self.logger.info("Matchable")
                    edges.append(j)
                    resourceList[j].append(i)
                    mediatorList[i][j]=mediator
                else:
                    self.logger.info("Not Matchable")
            jobList[i] = edges

        #this uses Hopcroft-Karp algorithm for maximal bipartate matchingMediator
        P = []

        for i in jobList:
            [result, newEdges] = self.bfs(resourceList, jobList, [], i, visitedJob, visitedResource, 'job', [i], [])
            if (result != False): #Important step for null results
                for j in newEdges:
                    visitedJob[j[0]]=1
                    visitedResource[j[1]]=1
                    mediator = mediatorList[j[0]][j[1]]
                    j.append(mediator)
                    if result: #if we found a successful graph
                        if j not in P:
                            P.append(j)
                        else:
                            P.remove(j) #Why would you remove it?

        return(P)

    def platformListener(self):
        self.active = True
        self.logger.info("Listening for contract events...")

        while self.active:
            events = self.contract.poll_events()
            for event in events:
                params = event['params']
                name = event['name']
                self.logger.info("{}({}).".format(name, params))
                if name == "MediatorRegistered":
                    self.logger.info("%s" %name)
                    self.mediators[params['addr']] = Pstruct.Mediator(params['arch'], params['instructionPrice'], params['bandwidthPrice'], params['dockerBandwidthPrice'])
                elif name == "ResourceProviderRegistered":
                    self.logger.info("%s" %name)
                    self.resource_providers[params['addr']] = Pstruct.ResourceProvider(params['arch'], params['timePerInstruction'])
                elif name == "JobCreatorRegistered":
                    self.logger.info("%s" %name)
                    self.job_creators[params['addr']] = Pstruct.JobCreator()
                elif name == "ResourceProviderAddedTrustedMediator":
                    self.logger.info("%s" %name)
                    self.logger.info("name : %s  addr : %s" %(name, params['addr']))
                    self.resource_providers[params['addr']].trustedMediators.append(params['mediator'])
                elif name == "JobCreatorAddedTrustedMediator":
                    self.logger.info("%s" %name)
                    self.job_creators[params['addr']].trustedMediators.append(params['mediator'])
                elif name == "ResourceOfferPosted":
                    self.logger.info("%s = %s" %(name, params["bandwidthPrice"]))
                    offer  = Pstruct.ResourceOffer(params['offerId'], params['resourceProvider'], params['instructionPrice'], params['instructionCap'], params['memoryCap'], params['localStorageCap'], params['bandwidthCap'], params['bandwidthPrice'], params['dockerBandwidthCap'], params['dockerBandwidthPrice'], params['deposit'] )
                    #self.resource_offers[params['resourceProvider']] =  offer
                    self.resource_offers[params['offerId']] = offer
                elif name == "JobOfferPosted":
                    self.logger.info("%s = %s" %(name, params["bandwidthMaxPrice"]))
                    offer = Pstruct.JobOffer(
                        params['offerId'], params['jobCreator'], params['size'],
                        params['arch'], params['instructionLimit'], params['ramLimit'],
                        params['localStorageLimit'], params['bandwidthLimit'],
                        params['instructionMaxPrice'], params['bandwidthMaxPrice'],
                        params['dockerBandwidthMaxPrice'], params['completionDeadline'], params['deposit'])
                    #self.job_offers[params['jobCreator']] = offer
                    self.job_offers[params['offerId']] = offer
                elif name == "JobOfferImagePosted":
                    self.logger.info("%s" %name)
                    self.logger.info(params['uri'])
                elif name == "Matched":
                    # self.logger.info("I: %s" %name)
                    self.logger.info("I: BC Job offer %s = %s" %(name, params['jobOfferId']))
                    self.logger.info("I: BC Resource offer %s = %s" %(name, params['resourceOfferId']))

            #after reading events call mathing

            matches = self.HopcroftKarp()
            # matches = self.GreedyMatches()
            if matches:
                self.logger.info(matches)
                self.logger.info(self.resource_providers)
                self.logger.info(self.resource_offers)
                self.logger.info(self.job_creators)
                self.logger.info(self.job_offers)
            for i in matches:
                self.logger.info("I: post match job offer = %s" %self.job_offers[i[0]].bandwidthMaxPrice)
                self.logger.info("I: post match resource offer = %s" %self.resource_offers[i[1]].bandwidthPrice)

                self.logger.info("jo id: %s" %self.job_offers[i[0]].offerId)
                self.logger.info("ro id: %s" %self.resource_offers[i[1]].offerId)
                self.contract.postMatch(self.account,
                                        self.job_offers[i[0]].offerId,
                                        self.resource_offers[i[1]].offerId,
                                        i[2])
                #remove matches from list
                self.job_offers.pop(i[0])
                self.resource_offers.pop(i[1])
            self.wait()
