class Mediator():
  def __init__(self, arch, instructionPrice, bandwidthPrice, dockerBandwidthPrice):
    self.arch = arch
    self.instructionPrice = instructionPrice
    self.bandwidthPrice = bandwidthPrice
    self.dockerBandwidthPrice = dockerBandwidthPrice
    #self.supportedDirectories = supportedDirectories
    #self.layers = layers
  def __eq__(self, other):
    """Overrides the default implementation"""
    if isinstance(other, Mediator):
        return (self.arch == other.arch and self.instructionPrice == other.instructionPrice and self.bandwidthPrice == other.bandwidthPrice and self.dockerBandwidthPrice == other.dockerBandwidthPrice)
    return False

class ResourceProvider():
  def __init__(self, arch, timePerInstruction):
    self.arch = arch
    #timePerInstruction must be in microseconds
    self.timePerInstruction = timePerInstruction
    self.trustedMediators = []

class JobCreator():
 def __init__(self):
    self.trustedMediators=[]


class JobOffer():
    #JobOfferPosted(uint offerId, address jobCreator, uint size, Architecture arch, uint instructionLimit, uint ramLimit, uint localStorageLimit, uint bandwidthLimit, uint instructionMaxPrice, uint bandwidthMaxPrice, uint dockerBandwidthMaxPrice, uint256 completionDeadline);
  def __init__(self, offerId="", jobCreator="", size="", arch="", instructionLimit="", ramLimit="", localStorageLimit="", bandwidthLimit="", instructionMaxPrice="", bandwidthMaxPrice="", dockerBandwidthMaxPrice="", completionDeadline="", deposit="", uri=""):
    self.offerId = offerId
    self.jobCreator = jobCreator
    self.size = size;
    self.arch = arch
    self.instructionLimit = instructionLimit
    self.ramLimit = ramLimit
    self.localStorageLimit = localStorageLimit
    self.bandwidthLimit = bandwidthLimit
    self.instructionMaxPrice = instructionMaxPrice
    self.bandwidthMaxPrice = bandwidthMaxPrice
    self.dockerBandwidthMaxPrice = dockerBandwidthMaxPrice
    self.completionDeadline = completionDeadline
    self.deposit = deposit
    self.uri = uri

class ResourceOffer():
    #ResourceOfferPosted(uint offerId, address resourceProvider, uint instructionPrice, uint instructionCap, uint memoryCap, uint localStorageCap, uint bandwidthCap, uint bandwidthPrice, uint dockerBandwidthCap, uint dockerBandwidthPrice);
  def __init__(self, offerId, resourceProvider, instructionPrice, instructionCap, memoryCap, localStorageCap, bandwidthCap, bandwidthPrice, dockerBandwidthCap, dockerBandwidthPrice, deposit):
    self.offerId = offerId
    #print(resourceProviderDict)
    self.resourceProvider =resourceProvider
    self.instructionPrice = instructionPrice
    self.instructionCap = instructionCap
    self.memoryCap = memoryCap
    self.localStorageCap = localStorageCap
    self.bandwidthCap = bandwidthCap
    self.bandwidthPrice = bandwidthPrice
    self.dockerBandwidthCap = dockerBandwidthCap
    self.dockerBandwidthPrice = dockerBandwidthPrice
    self.deposit = deposit

class Match():
  def __init__(self,   jobOfferId, resourceOfferId, mediator):
    self.jobOfferId = jobOfferId
    self.resourceOfferId = resourceOfferId
    self.mediator = mediator
