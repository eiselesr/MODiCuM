import logging
import logging.config
import os
import subprocess
import time
import traceback
import random

import dotenv
from apscheduler.schedulers.background import BackgroundScheduler

from . import DockerWrapper
from . import PlatformStructs as Pstruct
from .PlatformClient import PlatformClient


class JobCreator(PlatformClient):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger("JobCreator")
        # logging.config.fileConfig(os.path.dirname(__file__)+'/Modicum-log.conf')
        self.logger.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        # formatter = logging.Formatter("---%(name)s---: \n%(message)s\n\r")
        formatter = logging.Formatter("---%(name)s---:%(message)s")
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.job_offers = {}
        self.resource_offers = {}
        self.matches={}
        self.registered = False

        path = dotenv.find_dotenv('.env', usecwd=True)
        dotenv.load_dotenv(path)

        self.verificationChance = 0.10

        self.scheduler = BackgroundScheduler()
        self.scheduler.start()


    def register(self, account):
        self.logger.info("A: Registering")
        self.account = account
        self.contract.registerJobCreator(account)

    def addMediator(self,account,mediator):
        self.logger.info("B: Adding Mediator")
        self.contract.jobCreatorAddTrustedMediator(account, mediator)
        return 0

    def postOffer(self,msg):
        self.logger.info("D: Post offer = %s" %msg["bandwidthMaxPrice"])
        exitcode = self.contract.postJobOffer(
            self.account,
            msg["deposit"],
            msg["jobHash_int"],
            msg["uri"],
            self.account,
            msg["size"],
            msg["arch"],
            msg["cpuTime"],
            msg["memory"],
            msg["LocalStorageLimit"],
            msg["instructionMaxPrice"],
            msg["bandwidthMaxPrice"],
            msg["completionDeadline"])
        self.cliSocket.send_pyobj("job offer posted?: %s" %exitcode)

    def getResult(self,user, tag,resultID,RID, hash):
        _DIRIP_ = os.environ.get('DIRIP')
        _DIRPORT_ = os.environ.get('DIRPORT')
        _SSHKEY_ = os.environ.get('sshkey')
        _SSHPORT_ = os.environ.get('SSHPORT')
        _WORKPATH_ = os.environ.get('WORKPATH')

        localPath = "%s/%s/output" %(_WORKPATH_, tag)
        remotePath = "%s/output" %(tag)
        os.makedirs(localPath, exist_ok=True) #HACK
        self.logger.info("K: get result")
        self.DC.getData(_DIRIP_,_DIRPORT_,_SSHPORT_, user,
                        RID, remotePath, localPath,_SSHKEY_)
        self.logger.info("K: got result")

        # TODO check hash param is the same as DC.getData's hash

        self.logger.info("F: post result response for result = %s: " %resultID)
        self.contract.acceptResult(self.account, resultID)

        return 0

    def getJob(self, tag, matchID, JID, execute,ijoid):
        _DIRIP_ = os.environ.get('DIRIP')
        _DIRPORT_ = os.environ.get('DIRPORT')
        _KEY_ = os.environ.get('pubkey')
        _SSHKEY_ = os.environ.get('sshkey')
        _SSHPORT_ = os.environ.get('SSHPORT')
        _WORKPATH_ = os.environ.get('WORKPATH')
        statusJob=0
        cpuTime=0
        endStatus="Completed"

        try :
            self.logger.info("L: Requesting Permission to get job = %s" %ijoid)
            message, self.user = self.DC.getPermission(_DIRIP_, _DIRPORT_,self.account,tag,_KEY_)

            self.logger.info("L: permission granted? : %s = %s" %(message==0, ijoid))
            if message == 0:
                remotePath = tag
                self.logger.info([_DIRIP_,_SSHPORT_,self.user, JID, tag,_WORKPATH_ ,_SSHKEY_])
                localPath = "%s/%s/" %(_WORKPATH_, tag)
                if os.path.isfile("%s/%s:latest.tar" %(localPath,tag)): #HACK
                    self.logger.info("image exists, skip downloading it.")
                    localPath = "%s/input" %localPath
                    remotePath = "%s/input" %tag
                os.makedirs(localPath, exist_ok=True) #HACK
                self.logger.info("localPath: %s" %localPath)
                self.logger.info("remotePath: %s" %remotePath)
                self.logger.info("K: get job = %s" %ijoid)
                self.DC.getData(_DIRIP_,_DIRPORT_,_SSHPORT_, self.user, JID, remotePath, localPath,_SSHKEY_)
                self.logger.info("K: got job = %s" %ijoid)
            else:
                self.logger.info("Done.. but permission denied")
                statusJob=9
                endStatus="DirectoryUnavailable"

        except :
            self.logger.info(traceback.format_exc())
            statusJob=3
            endStatus="JobNotFound"


        try:
            if execute and statusJob==0:
                images = self.dockerClient.images.list(name=tag)
                self.logger.info(images)

                if not images:
                    self.logger.info("Image not loaded. loading image... ")
                    DockerWrapper.loadImage(self.dockerClient, "%s/%s/%s:latest.tar" %(_WORKPATH_, tag,tag))

                self.logger.info("Image is loaded")

                jobname = "mm_%s" %matchID
                input = "%s/%s/input" %(_WORKPATH_,tag)
                output = "%s/%s/output" %(_WORKPATH_,tag)
                appinput = "/app/input"
                appoutput = "/app/output"
                self.logger.info("Starting Docker for job = %s" %ijoid)
                container = DockerWrapper.runContainer(self.dockerClient, tag, jobname, input, output,appinput,appoutput)
                container.reload()
                lid = container.attrs["Id"]
                self.logger.info("container ID for job %s: %s" %(lid, ijoid))

                self.logger.info("G: running job = %s" %ijoid)
                cpu_old = -1
                stopping = False
                cmd = "cat /sys/fs/cgroup/cpuacct/docker/%s/cpuacct.stat | grep -oP '(?<=user ).*'" %lid
                while container.status == "running":

                    try:
                        completedprocess = subprocess.getoutput(cmd) #HACK the internet says something else should be used
                        cpuTime = int(completedprocess) * 10
                    except ValueError as err:
                        self.logger.info("Process is done... probably")
                        self.logger.info("error is : %s" %err)
                        self.logger.info("error type is : %s" %type(err))
                        self.logger.info("G: %s to run job = %s" %(cpuTime, ijoid))
                        self.logger.info("Stopping Docker for job = %s" %ijoid)
                        stopping = True
                        # if lid in err:
                        #     self.logger.info("Process is done")

                    startReload = time.time()
                    container.reload()
                    reloadDuration = time.time() - startReload
                    self.logger.info("reload took: %s" %reloadDuration)
                    self.logger.info("Container is : %s" %container.status)
                    self.logger.info("duration: %s ms" %cpuTime)

                    if cpu_old == cpuTime or container.status != "running":
                        if not stopping:
                            self.logger.info("G: %s to run job = %s" %(cpuTime, ijoid))
                            self.logger.info("Stopping Docker for job = %s" %ijoid)
                            stopping = True
                    else:
                        cpu_old = cpuTime
                        time.sleep(1)


                self.logger.info("Docker stopped for job = %s" %ijoid)
                self.logger.info("J: Send result to DIRECTORY for job = %s" %ijoid)
                self.DC.publishData(_DIRIP_, _SSHPORT_, self.user,tag,output,_SSHKEY_)
                self.logger.info("J: Data sent for job = %s" %ijoid)

                if self.account:
                    # TODO resultHash
                    resultHash = "b599cff993a602c14e6d45beab7a48c25e6753b7106cd6173488e843a7158060"
                    resultHash_int = int(resultHash, 16)

                    # TODO FAILURE HANDLING
                    return {
                        'match': matchID,
                        'status': 'Completed',
                        'tag': tag,
                        'resultHash': resultHash_int,
                        'cpuTime': cpuTime,
                        'bandwidthUsage': 0
                    }

                self.logger.info("Done")
                return 0
        except :
            self.logger.info(traceback.format_exc())
            statusJob=8
            endStatus="ExceptionOccured"

        if statusJob!=0:
            if self.account:
                #TODO resultHash
                resultHash = "b599cff993a602c14e6d45beab7a48c25e6753b7106cd6173488e843a7158060"
                resultHash_int = int(resultHash, 16)

                # #TODO FAILURE HANDLING
                return {
                    'match': matchID,
                    'status': endStatus,
                    'tag': tag,
                    'resultHash': resultHash_int,
                    'cpuTime': cpuTime,
                    'bandwidthUsage': 0
                }

    def publish(self,tag,path,postimage,postinput):
        _DIRIP_ = os.environ.get('DIRIP')
        _DIRPORT_ = os.environ.get('DIRPORT')
        _KEY_ = os.environ.get('pubkey')
        _SSHPORT_ = os.environ.get('SSHPORT')
        _SSHKEY_ = os.environ.get('sshkey')

        self.logger.info("L: Requesting Permission to publish")
        message, self.user = self.DC.getPermission(_DIRIP_,_DIRPORT_,self.account,tag,_KEY_)
        self.logger.info(message)
        self.logger.info("my username: %s" %self.user)
        self.logger.info("L: permission granted? : %s" %(message==0))
        if message == 0:
            if postimage:
                imagepath = "%s/image/*" %path
                print([_DIRIP_,_SSHPORT_,self.user,tag,imagepath,_SSHKEY_])
                self.logger.info("J: publish image")
                self.DC.publishData(_DIRIP_,_SSHPORT_,self.user,tag,imagepath,_SSHKEY_)
                self.logger.info("J: image published")
            if postinput:
                inputpath = "%s/input" %path
                self.logger.info("J: publish input")
                self.DC.publishData(_DIRIP_,_SSHPORT_,self.user,tag,inputpath,_SSHKEY_)
                self.logger.info("J: input published")
            return 0
        else:
            return 1

    def timeout(self, matchId):
        self.logger.info(f'Match {matchId} timed out.')
        self.contract.timeout(matchId)

    def scheduleTimeout(self, matchID, deadline_ms):
        self.logger.info("now: %s" %time.time())
        deadline_s = deadline_ms/1000
        self.logger.info("deadline: %s" %deadline_s)
        self.logger.info("type(deadline): %s" %type(deadline_s))

        to_run = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(deadline_s))
        self.scheduler.add_job(self.timeout, 'date', id=str(matchID), run_date=to_run, args=[matchID])

    def CLIListener(self):
        active = True
        while active:
            msg = self.cliSocket.recv_pyobj()
            self.logger.info("cli received: %s" %msg)
            if msg['request'] == "stop":
                active = False
                self.cliSocket.send_pyobj("stopping...")
                self.stop()
            elif msg['request'] == "addMediator":
                mediator = msg["mediator"]
                if self.account:
                    exitcode = self.addMediator(self.account, mediator)
                    self.cliSocket.send_pyobj("Mediator added? %s" %(exitcode==0) )
                else:
                    exitcode = 1
                    self.cliSocket.send_pyobj("Mediator added? %s, account is %s" %(exitcode==0, self.account) )



            elif msg['request'] == "publish":
                exitcode = self.publish(
                            msg["tag"],
                            msg["path"],
                            msg["postimage"],
                            msg["postinput"]
                            )
                self.logger.info("published? : %s" %(exitcode==0))
                self.cliSocket.send_pyobj("published? : %s" %(exitcode==0))
            elif msg['request'] == "post":
                self.postOffer(msg)
            elif msg['request'] =="getResult":
                exitcode = self.getResult(
                                msg["user"],
                                msg["tag"],
                                msg["resultID"],
                                msg["RID"],
                                    0 # TODO this is the expected hash of result.
                                )
                self.cliSocket.send_pyobj("got result? : %s" %(exitcode==0))

    def platformListener(self):
        self.active = True
        while self.active:
            events = self.contract.poll_events()
            # self.logger.info("poll contract events")
            for event in events:
                params = event['params']
                name = event['name']
                # self.logger.info("{}({}).".format(name, params))
                if name == "JobCreatorRegistered":
                    self.addr = params['addr']
                    self.logger.info("A: %s" %name)
                elif name == "JobCreatorAddedTrustedMediator":
                    self.logger.info("B: %s" %name)
                elif name == "ResourceOfferPosted":
                    self.logger.info("%s" %name)
                    offer  = Pstruct.ResourceOffer(
                        params['offerId'], params['resourceProvider'],
                        params['instructionPrice'], params['instructionCap'],
                        params['memoryCap'], params['localStorageCap'],
                        params['bandwidthCap'], params['bandwidthPrice'],
                        params['dockerBandwidthCap'], params['dockerBandwidthPrice'], params['deposit'])
                    self.resource_offers[params['offerId']] =  offer
                elif name == "JobOfferPosted":
                    self.logger.info("D: %s = %s" %(name,params["bandwidthMaxPrice"]))
                    if self.addr == params['jobCreator']:
                        if params['offerId'] not in self.job_offers:
                            offer = Pstruct.JobOffer(
                                params['offerId'], params['jobCreator'], params['size'],
                                params['arch'], params['instructionLimit'], params['ramLimit'],
                                params['localStorageLimit'], params['bandwidthLimit'],
                                params['instructionMaxPrice'], params['bandwidthMaxPrice'],
                                params['dockerBandwidthMaxPrice'], params['completionDeadline'], params['deposit'])
                            self.job_offers[params['offerId']] = offer
                        else:
                            offerId = params['offerId'] # TODO it should be here! but it wasn't before :-? is there any reason to that?
                            self.job_offers[offerId].offerId = params['offerId']
                            self.job_offers[offerId].jobCreator = params['jobCreator']
                            self.job_offers[offerId].size = params['size']
                            self.job_offers[offerId].arch = params['arch']
                            self.job_offers[offerId].instructionLimit = params['instructionLimit']
                            self.job_offers[offerId].ramLimit = params['ramLimit']
                            self.job_offers[offerId].localStorageLimit = params['localStorageLimit']
                            self.job_offers[offerId].bandwidthLimit = params['bandwidthLimit']
                            self.job_offers[offerId].instructionMaxPrice = params['instructionMaxPrice']
                            self.job_offers[offerId].bandwidthMaxPrice = params['bandwidthMaxPrice']
                            self.job_offers[offerId].dockerBandwidthMaxPrice = params['dockerBandwidthMaxPrice']
                            self.job_offers[offerId].completionDeadline = params['completionDeadline']
                            self.job_offers[offerId].deposit = params['deposit']


                elif name == "JobOfferImagePosted":
                    offerId = params['offerId']
                    self.logger.info("D: %s" %name)

                    if offerId in self.job_offers:
                        uri  = params['uri']
                        self.logger.info(uri)
                        self.job_offers[offerId].uri = params['uri']
                    else:
                        offer = Pstruct.JobOffer(params['uri'])


                elif name == "Matched":
                    joid = params['jobOfferId']
                    if joid in self.job_offers:
                        self.logger.info("Job offer %s = %s" %(name, self.job_offers[params['jobOfferId']].bandwidthMaxPrice))
                        self.logger.info("Resource offer %s = %s" %(name, self.resource_offers[params['resourceOfferId']].bandwidthPrice))

                        matchID = params["matchId"]
                        match = Pstruct.Match(
                            params["jobOfferId"], params["resourceOfferId"], params["mediator"]
                        )
                        self.matches[matchID] = match

                        completionDeadline = self.job_offers[params['jobOfferId']].completionDeadline
                        self.logger.info("Job offer completionDeadline: %s" %completionDeadline)
                        self.logger.info("now: %s" %time.time())
                        self.scheduleTimeout(matchID, completionDeadline)


                elif name == "ResultPosted":
                    if params["matchId"] in self.matches:
                        matchID = params["matchId"]
                        tag = params["uri"]
                        resultId = params["resultId"]
                        joid = self.matches[matchID].jobOfferId
                        ijoid = self.job_offers[joid].bandwidthMaxPrice
                        roid = self.matches[matchID].resourceOfferId
                        iroid = self.resource_offers[roid].bandwidthPrice
                        RID = self.resource_offers[roid].resourceProvider

                        self.logger.info("%s Job = %s" %(name, ijoid))
                        self.logger.info("%s Resource = %s" %(name, iroid))

                        self.logger.info("result status: %s" %params["status"])
                        self.logger.info("result status type: %s" %type(params["status"]))

                        self.scheduler.remove_job(job_id=str(matchID))

                        if not params['status'] == 'ResultStatus.Completed':
                            self.logger.info("Job was not completed correctly")
                            self.logger.info("M: Mediation requested = %s" % matchID)
                            self.contract.rejectResult(self.account, resultId)
                            continue

                        if random.uniform(0, 1) < self.verificationChance:
                            self.logger.info(f'verifying match {matchID} results...')
                            myResult = self.getJob(tag, matchID, joid, True, ijoid)
                            if myResult['hash'] == params['hash']:
                                self.logger.info("Get result for matchID %s" % matchID)
                                exitcode = self.getResult(self.user, tag, resultId, RID, params['hash'])
                            else:
                                self.logger.info("M: Mediation requested = %s" % matchID)
                                self.contract.rejectResult(self.account, resultId)
                        else:
                            self.logger.info("Get result for matchID %s" % matchID)
                            exitcode = self.getResult(self.user, tag, resultId, RID, params['hash'])

                elif name == "ResultReaction":
                    self.logger.info("F: %s resultId = %s" %(name, params["resultId"]))
                elif name == "MatchClosed":
                    matchID = params["matchId"]
                    joid = self.matches[matchID].jobOfferId
                    ijoid = self.job_offers[joid].bandwidthMaxPrice
                    roid = self.matches[matchID].resourceOfferId
                    iroid = self.resource_offers[roid].bandwidthPrice

                    self.logger.info("F: %s Job = %s" %(name, ijoid))
                    self.logger.info("F: %s Resource = %s" %(name, iroid))
                    # eventSender =zmq.Context().socket(zmq.REQ)
                    # eventSender.connect("tcp://%s:%s" %('localhost',3333))
                    # msg = {"request": "continue"}
                    # eventSender.send_pyobj(msg)
                    # response = eventSender.recv_pyobj()
                elif name == "JobAssignedForMediation":
                    self.logger.info("M: %s = %s" %(name, params["matchId"]))

            self.wait()
