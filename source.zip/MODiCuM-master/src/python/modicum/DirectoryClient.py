import logging
import fabric.api as fabi
import zmq

class DirectoryClient():
    def __init__(self):
        self.logger = logging.getLogger("Directory Client")
        self.context = zmq.Context()

    def test(self):
        print("OK")

    def fabput(self,local,remote):
        fabi.put(local,remote,mode="0754")

    def fabget(self,local,remote):
        fabi.get(remote, local)

    def publishData(self,host,port,ID,job,localpath,sshpath):
        '''sftp job to directory'''
        self.logger.debug([host,port,ID,job,localpath,sshpath])
        remotePath = "/home/%s/%s/" %(ID,job)
        fabi.env.key_filename = sshpath
        fabi.execute(self.fabput, localpath, remotePath, hosts=ID+"@"+host+":"+port)

    def getData(self,host,cliport,sshport,user,remoteID,job,localPath,sshpath):
        '''sftp job from directory'''
        self.logger.info("get username of wallet")
        directory_socket = self.context.socket(zmq.REQ)
        directory_socket.connect("tcp://%s:%s" %(host,cliport))
        msg = {
            'request' : "get_username",
            'ID' : remoteID
        }
        directory_socket.send_pyobj(msg)
        remote_user = directory_socket.recv_pyobj()
        self.logger.info("remote username: %s" %remote_user)

        self.logger.info("actor getData")
        remotePath = "/home/%s/%s/*" %(remote_user,job)
        fabi.env.key_filename = sshpath
        fabi.execute(self.fabget, localPath, remotePath, hosts=user+"@"+host+":"+sshport)

    def getPermission(self,host,port,ID,job,pubkey):
        '''send getPermission request to Directory service at ip:port'''
        directory_socket = self.context.socket(zmq.REQ)
        print(host)
        directory_socket.connect("tcp://%s:%s" %(host,port))
        msg = {
          'request': "get_permission",
          "ID":ID,
          "job": job,
          "pubkey":pubkey
        }
        directory_socket.send_pyobj(msg)
        message = directory_socket.recv_pyobj()
        print(message)
        return message['exitcode'], message['user']

    def getSize(self, ip, port, ID, job):
        '''get size of file to download'''
        #TODO: Could be done with fabric?
        # socket = self.context.socket(zmq.REQ)
        # socket.connect("tcp://%s:%s" %(ip,port))
        # msg = {
        #   'request': "get_size",
        #   "ID":ID,
        #   "pubKey":"12345",
        #   "job":job
        # }
        # self.logger.info("Actor message to send: %s" %msg)
        # socket.send_pyobj(msg)
        # message = socket.recv_pyobj()
        # return message
