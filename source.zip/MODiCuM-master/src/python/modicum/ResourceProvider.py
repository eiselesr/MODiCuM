import logging
import logging.config
import os
import subprocess
# from . import DirectoryClient
from . import DockerWrapper
from .PlatformClient import PlatformClient
from . import PlatformStructs as Pstruct
import dotenv
import time
import traceback
from apscheduler.schedulers.background import BackgroundScheduler

class ResourceProvider(PlatformClient):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger("ResourceProvider")
        # logging.config.fileConfig(os.path.dirname(__file__)+'/Modicum-log.conf')
        self.logger.setLevel(logging.INFO)
        ch = logging.StreamHandler()
        # formatter = logging.Formatter("---%(name)s---: \n%(message)s\n\r")
        formatter = logging.Formatter("---%(name)s---:%(message)s")

        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.job_offers = {}
        self.resource_offers = {}
        self.matches ={}
        self.registered = False
        self.offerq = list()
        self.idle = True

        path = dotenv.find_dotenv('.env', usecwd=True)
        dotenv.load_dotenv(path)

        self.scheduler = BackgroundScheduler()
        self.scheduler.start()

    def register(self, account, arch, timePerInstruction):
        self.logger.info("A: Registering")
        self.account = account
        self.contract.registerResourceProvider(account, arch, timePerInstruction)

    def addMediator(self,account,mediator):
        self.logger.info("B: Adding Mediator")
        self.contract.resourceProviderAddTrustedMediator(account, mediator)
        return 0

    def postOffer(self,msg):
        if self.idle:
            self.idle = False
            self.logger.info("C: Post resource offer = %s" %msg["bandwidthPrice"])
            exitcode = self.contract.postResOffer(self.account,
                            msg["deposit"],
                            msg["instructionPrice"],
                            msg["instructionCap"],
                            msg["memoryCap"],
                            msg["localStorageCap"],
                            msg["bandwidthCap"],
                            msg["bandwidthPrice"])
            return exitcode
        else:
            self.offerq.insert(0,msg)
            self.logger.info("RP is busy. Submit offer later")
            return 1

    def acceptResult(self, resultId):
        self.logger.info('JC Missed deadline for reacting to results.')
        self.contract.acceptResult(self.account, resultId)

    def scheduleAcceptResult(self, resultId, delay):
        to_run = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() + delay))
        self.scheduler.add_job(self.acceptResult, 'date', id=str(resultId), run_date=to_run, args=[resultId])

    def getJob(self, tag, matchID, JID, execute,ijoid):
        _DIRIP_ = os.environ.get('DIRIP')
        _DIRPORT_ = os.environ.get('DIRPORT')
        _KEY_ = os.environ.get('pubkey')
        _SSHKEY_ = os.environ.get('sshkey')
        _SSHPORT_ = os.environ.get('SSHPORT')
        _WORKPATH_ = os.environ.get('WORKPATH')
        statusJob=0
        cpuTime=0
        endStatus="Completed"

        try :
            self.logger.info("L: Requesting Permission to get job = %s" %ijoid)
            message, self.user = self.DC.getPermission(_DIRIP_, _DIRPORT_,self.account,tag,_KEY_)

            self.logger.info("L: permission granted? : %s = %s" %(message==0, ijoid))
            if message == 0:
                remotePath = tag
                self.logger.info([_DIRIP_,_SSHPORT_,self.user, JID, tag,_WORKPATH_ ,_SSHKEY_])
                localPath = "%s/%s/" %(_WORKPATH_, tag)
                if os.path.isfile("%s/%s:latest.tar" %(localPath,tag)): #HACK
                    self.logger.info("image exists, skip downloading it.")
                    localPath = "%s/input" %localPath
                    remotePath = "%s/input" %tag
                os.makedirs(localPath, exist_ok=True) #HACK
                self.logger.info("localPath: %s" %localPath)
                self.logger.info("remotePath: %s" %remotePath)
                self.logger.info("K: get job = %s" %ijoid)
                self.DC.getData(_DIRIP_,_DIRPORT_,_SSHPORT_, self.user, JID, remotePath, localPath,_SSHKEY_)
                self.logger.info("K: got job = %s" %ijoid)
            else:
                self.logger.info("Done.. but permission denied")
                statusJob=9
                endStatus="DirectoryUnavailable"

        except :
            self.logger.info(traceback.format_exc())
            statusJob=3
            endStatus="JobNotFound"


        try:
            if execute and statusJob==0:
                images = self.dockerClient.images.list(name=tag)
                self.logger.info(images)

                if not images:
                    self.logger.info("Image not loaded. loading image... ")
                    DockerWrapper.loadImage(self.dockerClient, "%s/%s/%s:latest.tar" %(_WORKPATH_, tag,tag))

                self.logger.info("Image is loaded")

                jobname = "mm_%s" %matchID
                input = "%s/%s/input" %(_WORKPATH_,tag)
                output = "%s/%s/output" %(_WORKPATH_,tag)
                appinput = "/app/input"
                appoutput = "/app/output"
                self.logger.info("Starting Docker for job = %s" %ijoid)
                container = DockerWrapper.runContainer(self.dockerClient, tag, jobname, input, output,appinput,appoutput)
                # container.reload()
                lid = container.attrs["Id"]
                self.logger.info("container ID for job %s: %s" %(lid, ijoid))

                self.logger.info("G: running job = %s" %ijoid)
                cpu_old = -1
                stopping = False
                cmd = "cat /sys/fs/cgroup/cpuacct/docker/%s/cpuacct.stat | grep -oP '(?<=user ).*'" %lid

                self.logger.info(container.status)
                while container.status != "running":
                    time.sleep(1)
                    container.reload()
                    self.logger.info(container.status)
                while container.status == "running":
                    try:
                        completedprocess = subprocess.getoutput(cmd) #HACK the internet says something else should be used
                        cpuTime = int(completedprocess) * 10
                    except ValueError as err:
                        self.logger.info("Process is done... probably")
                        self.logger.info("error is : %s" %err)
                        self.logger.info("error type is : %s" %type(err))
                        self.logger.info("G: %s to run job = %s" %(cpuTime, ijoid))
                        self.logger.info("Stopping Docker for job = %s" %ijoid)
                        stopping = True
                        # if lid in err:
                        #     self.logger.info("Process is done")

                    startReload = time.time()
                    container.reload()
                    reloadDuration = time.time() - startReload
                    self.logger.info("reload took: %s" %reloadDuration)
                    self.logger.info("Container is : %s" %container.status)
                    self.logger.info("duration: %s ms" %cpuTime)

                    if cpu_old == cpuTime or container.status != "running":
                        if not stopping:
                            self.logger.info("G: %s to run job = %s" %(cpuTime, ijoid))
                            self.logger.info("Stopping Docker for job = %s" %ijoid)
                            stopping = True
                    else:
                        cpu_old = cpuTime
                        time.sleep(1)


                self.logger.info("Docker stopped for job = %s" %ijoid)
                self.logger.info("J: Send result to DIRECTORY for job = %s" %ijoid)
                self.DC.publishData(_DIRIP_, _SSHPORT_, self.user,tag,output,_SSHKEY_)
                self.logger.info("J: Data sent for job = %s" %ijoid)

                if self.account:
                    #TODO resultHash
                    resultHash = "b599cff993a602c14e6d45beab7a48c25e6753b7106cd6173488e843a7158060"
                    resultHash_int = int(resultHash, 16)

                    # #TODO FAILURE HANDLING
                    self.logger.info("H: post result for job = %s" %ijoid)
                    self.contract.postResult(self.account,
                        matchID, "Completed", tag, resultHash_int, cpuTime, 0, 0)

                self.logger.info("Done")
                return 0
        except :
            self.logger.info(traceback.format_exc())
            statusJob=8
            endStatus="ExceptionOccured"

        if statusJob!=0:
            if self.account:
                #TODO resultHash
                resultHash = "b599cff993a602c14e6d45beab7a48c25e6753b7106cd6173488e843a7158060"
                resultHash_int = int(resultHash, 16)

                # #TODO FAILURE HANDLING
                self.logger.info("H: post result: %s" %endStatus)
                self.contract.postResult(self.account,
                    matchID, endStatus, tag, resultHash_int, cpuTime, 0, 0)



    def CLIListener(self):
        active = True
        while active:
            msg = self.cliSocket.recv_pyobj()
            self.logger.info("cli received: %s" %msg)
            if msg['request'] == "stop":
                active = False
                self.cliSocket.send_pyobj("stopping...")
                self.stop()
            elif msg['request'] == "addMediator":
                mediator = msg["mediator"]
                if self.account:
                    exitcode = self.addMediator(self.account, mediator)
                    self.cliSocket.send_pyobj("Mediator added? %s" %(exitcode==0) )
                else:
                    exitcode = 1
                    self.cliSocket.send_pyobj("Mediator added? %s, account is %s" %(exitcode==0, self.account) )

            elif msg['request'] == "publish":
                self.logger.info("L: Requesting Permission to get job")
                response, self.user = self.DC.getPermission(msg["host"],msg["port"],msg["jcID"],msg["job"],msg["pubkey"])
                self.logger.info("L: permission granted? : %s" %(message==0))

                self.logger.info("J: Send result to DIRECTORY")
                self.DC.publishData(msg["host"],msg["sftport"],msg["jcID"],msg["job"],msg["localpath"],msg["sshpath"])
                self.logger.info("J: result sent")
                self.cliSocket.send_pyobj("data published")
            elif msg['request'] == "post":
                exitcode = self.postOffer(msg)
                if exitcode == 0:
                    self.logger.info("resource offer posting")
                    self.cliSocket.send_pyobj("resource offer posting")
                elif exitcode == 1:
                    self.logger.info("resource offer queued")
                    self.cliSocket.send_pyobj("resource offer queued")

            elif msg['request'] == "getJob":
                exitcode = self.getJob(
                    msg['tag'],
                    msg['matchID'],
                    msg['JID'],
                    msg['execute'],
                    msg['ijoid']
                    )
                self.cliSocket.send_pyobj(exitcode)


    def platformListener(self):
        self.active = True
        while self.active:
            events = self.contract.poll_events()
            # self.logger.info("poll contract events")
            for event in events:
                params = event['params']
                name = event['name']
                # self.logger.info("{}({}).".format(name, params))
                if name == "ResourceProviderRegistered" and self.account == params['addr']:
                # if name == "ResourceProviderRegistered":
                #     self.addr = params['addr']
                    self.logger.info("A: %s" %name)
                elif name == "ResourceProviderAddedTrustedMediator" and self.account == params['addr']:
                    self.logger.info("B: %s" %name)
                elif name == "ResourceOfferPosted" and self.account == params['resourceProvider']:
                    self.logger.info("C: %s = %s" %(name,params["bandwidthPrice"]))
                    self.logger.info("OfferID: %s" %params['offerId'])

                    offer  = Pstruct.ResourceOffer(
                        params['offerId'], params['resourceProvider'],
                        params['instructionPrice'], params['instructionCap'],
                        params['memoryCap'], params['localStorageCap'],
                        params['bandwidthCap'], params['bandwidthPrice'],
                        params['dockerBandwidthCap'], params['dockerBandwidthPrice'], params['deposit'] )

                    self.resource_offers[params['offerId']] =  offer

                elif name == "JobOfferPosted":
                    self.logger.info("%s" %name)
                    offer = Pstruct.JobOffer(
                        params['offerId'], params['jobCreator'], params['size'],
                        params['arch'], params['instructionLimit'], params['ramLimit'],
                        params['localStorageLimit'], params['bandwidthLimit'],
                        params['instructionMaxPrice'], params['bandwidthMaxPrice'],
                        params['dockerBandwidthMaxPrice'], params['completionDeadline'], params['deposit'])
                    self.job_offers[params['offerId']] = offer
                elif name == "JobOfferImagePosted":
                    self.logger.info("%s" %name)
                    uri  = params['uri']
                    self.logger.info(uri)
                    offerId = params['offerId']
                    self.job_offers[offerId].uri = params['uri']
                elif name == "Matched":
                    joid = params['jobOfferId']
                    roid = params['resourceOfferId']
                    if roid in self.resource_offers:
                        ijoid = self.job_offers[joid].bandwidthMaxPrice
                        self.logger.info("%s Job = %s" %(name, ijoid))
                        iroid = self.resource_offers[roid].bandwidthPrice
                        self.logger.info("%s Resource = %s" %(name, iroid))
                        matchID = params["matchId"]
                        uri = self.job_offers[joid].uri
                        self.logger.info("@@@  URI  @@@ %s" %uri)
                        JID = self.job_offers[joid].jobCreator
                        self.getJob(uri, matchID, JID,True,ijoid)
                        self.matches[matchID] = {"uri":uri,"JID":JID,"execute":True}

                elif name == "ResultPosted" and params["matchId"] in self.matches:
                    self.logger.info("H: %s" %name)
                    self.logger.info("result posted for matchId : %s" %params["matchId"])
                    self.matches[params['matchId']]['resultId'] = params['resultId']
                    # self.scheduleAcceptResult(params['resultId'], 1440)

                elif name == "ResultReaction" and params["matchId"] in self.matches:
                    pass
                    # self.scheduler.remove_job(str(params['resultId']))

                elif name == "MatchClosed" and params["matchId"] in self.matches:
                    self.logger.info("%s" %name)
                    self.idle = True

                elif name == "DebugString":
                    self.logger.info(params["str"])

            if self.idle and self.offerq:
                offer = self.offerq.pop()
                self.postOffer(offer)

            self.wait()
