OUT=/home/riaps/projects/MODiCuM/experimental/docker/500x500/run5
mkdir -p $OUT

# NAME='mm1'
# echo $NAME
# cmd="'SELECT value FROM memory_working_set WHERE container_name='"'${NAME}'"''"

sudo influx -database 'cadvisor' \
            -host 'localhost' \
            -execute "SELECT last(value) FROM cpu_usage_user WHERE container_name='mm_1'" \
            -format 'csv' > $OUT/cpu_usage_user_last.csv

sudo influx -database 'cadvisor' \
            -host 'localhost' \
            -execute "SELECT mean(value) FROM memory_working_set WHERE container_name='mm_1'" \
            -format 'csv' > $OUT/memory_working_set_mean.csv

sudo influx -database 'cadvisor' \
            -host 'localhost' \
            -execute "SELECT value FROM cpu_usage_user WHERE container_name='mm_1'" \
            -format 'csv' > $OUT/cpu_usage_user.csv

sudo influx -database 'cadvisor' \
            -host 'localhost' \
            -execute "SELECT value FROM memory_working_set WHERE container_name='mm_1'" \
            -format 'csv' > $OUT/memory_working_set.csv

sudo influx -database 'cadvisor' \
            -host 'localhost' \
            -execute "SELECT value FROM memory_usage WHERE container_name='mm_1'" \
            -format 'csv' > $OUT/memory_usage.csv
