#---------------------------------
# CONFIG fabric hosts
#---------------------------------

hosts ={'bbb-c470': '172.21.20.9', 'bbb-b4bc': '172.21.20.33',
        'bbb-a327': '172.21.20.15', 'bbb-235d': '172.21.20.42',
        'bbb-e1ec': '172.21.20.14', 'bbb-a702': '172.21.20.46',
        'bbb-4c23': '172.21.20.55', 'bbb-8014': '172.21.20.57',
        'bbb-29a6': '172.21.20.11', 'bbb-6302': '172.21.20.54',
        'bbb-5eb7': '172.21.20.48', 'bbb-1b70': '172.21.20.47',
        'bbb-ed97': '172.21.20.36', 'bbb-41b1': '172.21.20.18',
        'bbb-99b4': '172.21.20.45', 'bbb-7d6a': '172.21.20.56',
        'bbb-bce4': '172.21.20.38', 'bbb-c189': '172.21.20.39',
        'bbb-c452': '172.21.20.10', 'bbb-c473': '172.21.20.44',
        'bbb-e4ff': '172.21.20.12', 'bbb-2592': '172.21.20.17',
        'bbb-96af': '172.21.20.37', 'bbb-50c9': '172.21.20.16',
        'bbb-95f9': '172.21.20.41', 'bbb-ede8': '172.21.20.13',
        'bbb-b957': '172.21.20.43', 'bbb-bcf6': '172.21.20.40'}

VUtestNode = "129.59.105.167"
HomeTestNode = "192.168.137.227"
ClusterTestNode = hosts['bbb-b4bc']

#---------------------------------
# CONFIG MINER
#---------------------------------
MINER_DIR = "~/projects/miner"
CLUSTER_IP = '172.21.20.70'
VU_IP = '129.59.105.24'
HOME_IP = '10.0.0.2'
HOME_IP = '10.0.2.15'
GETH_IP = VU_IP
GETH_PORT = '10000'
# TRANSACTION_GAS = "0x20000000000"
TRANSACTION_GAS = "0x10000000"
#---------------------------------
# CONFIG Contract Manager
#---------------------------------
MANA_IP = VU_IP


#---------------------------------
# CONFIG Actors
#---------------------------------
SOLVER_IP = '172.21.20.70'

RECORDER_IP = '172.21.20.70'

#Directory
DIR_IP = "localhost"
DIR_PORT = "5555"
CHILD_PORT = "5556"

#---------------------------------
# CONFIG Job
#---------------------------------
# Path to dev job Dockerfile
jobPath = "/home/riaps/projects/MODiCuM/tests/jobs/matrix"
#dev path to app input
jobInputPath = "/home/riaps/projects/MODiCuM/tests/jobs/matrix/input"
# job tag for produced image
tag = "matrix_multiplication"
# Path to image
imagePath = "/home/riaps/projects/MODiCuM/tests/jobs/matrix/image"

# Path to production apps/dockerfiles/etc.
WORKPATH="/home/riaps/modicum-apps"
