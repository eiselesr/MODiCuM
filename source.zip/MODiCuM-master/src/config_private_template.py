username = 'dockerusername'
password = 'dockerpassword'

dirpwd = "directorypassword"

rsa_private_key = "path_to_actor_private_key"
pubKey = "the_corresponding_public_key_string"
