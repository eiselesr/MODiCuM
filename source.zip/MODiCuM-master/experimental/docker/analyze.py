# import sys
# import glob
import os
# import time,datetime
# import numpy as np
cpuTime=[]
avgMem=[]
startDir = os.getcwd()
for root,dirs, files in os.walk(startDir):
    # print(root)

    # print(files)
    for filename in files:
        if "last" in filename or "mean" in filename:
            print("%s/%s" %(root,filename))
            with open("%s/%s" %(root,filename)) as fp:
                lines=fp.readlines()
                for line in lines:
                    if 'cpu_usage_user' in line:
                        usage =line.split(',')[2]
                        cpuTime.append(usage)
                    elif 'memory_working_set' in line:
                        usage =line.split(',')[2]
                        avgMem.append(usage)




file1=open("cpuTime.csv","w")
file1.write("cpuTime\n")

file2=open("avgMem.csv","w")
file2.write("avgMem\n")


for entry in cpuTime:
    print("cpuTime value;"+str(entry))
    file1.write(entry)

for entry in avgMem:
    print("avgMem value;"+str(entry))
    file2.write(entry)
