fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput0.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"
fab -H 172.21.20.61 runCommand:"modicum postJob"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer"
fab -H 172.21.20.61 runCommand:"modicum wait4Completion"
