It used myInput2.json which are 2 500x500 matrices.
