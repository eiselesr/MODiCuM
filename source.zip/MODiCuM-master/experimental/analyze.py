import sys
import glob, os
import time,datetime
import numpy as np

class Offer():
    def __init__(self,id):
        self.id=id
        self.post=''
        self.posted=''
    def timedifference(self):
        #print(self.post+" "+str(self.id))
        #print(self.posted+" "+str(self.id))
        a=datetime.datetime.strptime(self.post, "%Y-%m-%d %H:%M:%S,%f")
        b=datetime.datetime.strptime(self.posted, "%Y-%m-%d %H:%M:%S,%f")
        return (b-a).total_seconds()
    def __str__(self):
        return ("%s;%s"%(self.id,self.timedifference()))
RPOffer={}
JOOffer={}
RegisterOffer={}
AddingMediator={}
Match={}
Result={}
Execution={}
nextContainerID = False
for filename in glob.glob("*.log"):
    #print(filename)
    with open(filename) as fp:
        lines = fp.readlines()
        for line in lines:
            if "ResourceProvider;C: Post resource offer" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                a=Offer(id)
                a.post=time
                RPOffer[id]=a
            if "Mediator;A: Registering" in line:
                time =line.split(';')[0]
                id="Mediator"+filename
                a=Offer(id)
                a.post=time
                RegisterOffer[id]=a
            if "Mediator;A: MediatorRegistered" in line:
                time =line.split(';')[0]
                id="Mediator"+filename
                RegisterOffer[id].posted=time
            if "JobCreator;A: Registering" in line:
                time =line.split(';')[0]
                id="JobCreator"+filename
                a=Offer(id)
                a.post=time
                RegisterOffer[id]=a
            if "ResourceProvider;B: Adding Mediator" in line:
                time =line.split(';')[0]
                id="RP:Mediator"+filename
                a=Offer(id)
                a.post=time
                AddingMediator[id]=a
            if "ResourceProvider;B: ResourceProviderAddedTrustedMediator" in line:
                time =line.split(';')[0]
                id="RP:Mediator"+filename
                AddingMediator[id].posted=time
            if "JobCreator;B: Adding Mediator" in line:
                time =line.split(';')[0]
                id="JC:AddingMediator"+filename
                a=Offer(id)
                a.post=time
                AddingMediator[id]=a
            if "JobCreator;B: JobCreatorAddedTrustedMediator" in line:
                time =line.split(';')[0]
                id="JC:AddingMediator"+filename
                AddingMediator[id].posted=time

            if "JobCreator;A: JobCreatorRegistered" in line:
                time =line.split(';')[0]
                id="JobCreator"+filename
                RegisterOffer[id].posted=time
            if "ResourceProvider;A: Registering" in line:
                time =line.split(';')[0]
                id="ResourceProvider"+filename
                a=Offer(id)
                a.post=time
                RegisterOffer[id]=a
            if "ResourceProvider;A: ResourceProviderRegistered" in line:
                time =line.split(';')[0]
                id="ResourceProvider"+filename
                RegisterOffer[id].posted=time
            if "JobCreator;D: Post offer" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                a=Offer(id)
                b=Offer(id)
                c=Offer(id)
                a.post=time
                b.post=time
                c.post=time
                JOOffer[id]=a
                Match[id]=b
                Result[id]=c

            if "ResourceProvider;C: ResourceOfferPosted" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                print(filename)
                RPOffer[id].posted=time
                # print(str(RPOffer[id]))
            if "JobCreator;D: JobOfferPosted" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                JOOffer[id].posted=time
            if "JobCreator;Job offer Matched" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                Match[id].posted=time
            if "JobCreator;ResultPosted Job" in line:
                time =line.split(';')[0]
                id=int(line.split('=')[1])
                Result[id].posted=time
            if "to run job" in line:
                print(line)
                nodeID = filename.split("node")[1]
                jid=int(line.split('=')[1])
                id="G"+nodeID+str(jid)
                Execution[id] = int(line.split(" ")[2])/1000
            # if "ResourceProvider;G: running job" in line:
            #     time =line.split(';')[0]
            #     id=int(line.split('=')[1])
            #     nodeID = filename.split("node")[1]
            #     id="G"+nodeID+str(id)
            #     a=Offer(id)
            #     a.post=time
            #     Execution[id]=a
            # if "ResourceProvider;G:" in line and "to run job" in line:
            #     time =line.split(';')[0]
            #     id=int(line.split('=')[1])
            #     nodeID = filename.split("node")[1]
            #     id="G"+nodeID+str(id)
            #     Execution[id].posted=time







file1=open("JOO.csv","w")
file1.write("JobOfferPostTime\n")
file2=open("RPO.csv","w")
file2.write("ResourceOfferPostTime\n")
file3=open("Register.csv","w")
file3.write("RegistrationTime\n")
file4=open("MediatorAddition.csv","w")
file4.write("MediationTime\n")
file5=open("Match.csv","w")
file5.write("OfferMatchTime\n")
file6=open("ExecutionTime.csv", "w")
file6.write("ExecutionTime\n")
file7=open("Result.csv","w")
file7.write("JobCompletionTime\n")

for entry in JOOffer.values():
    print("JO Offer;"+str(entry))
    file1.write(str(entry).split(";")[1]+"\n")


for entry in RPOffer.values():
    print("RP Offer;"+str(entry))

    file2.write(str(entry).split(";")[1]+"\n")

for entry in RegisterOffer.values():
    print("Register;"+str(entry))
    file3.write(str(entry).split(";")[1]+"\n")

for entry in AddingMediator.values():
    print("AddingMediator;"+str(entry))
    file4.write(str(entry).split(";")[1]+"\n")

for entry in Match.values():
    print("Match;"+str(entry))
    file5.write(str(entry).split(";")[1]+"\n")

for entry in Execution.values():
    print("ExecutionTime;"+str(entry))
    file6.write(str(entry)+"\n")
# for entry in Execution.values():
#     print("ExecutionTime;"+str(entry))
#     file6.write(str(entry).split(";")[1]+"\n")

for entry in Result.values():
    print("Result;"+str(entry))
    file7.write(str(entry).split(";")[1]+"\n")
