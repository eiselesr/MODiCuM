It used myInput1.json which are 2 500x500 matrices.
