It used myInput1.json which are 2 1000x1000 matrices.
