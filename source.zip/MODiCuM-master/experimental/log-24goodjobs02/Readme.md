It used myInput1.json which are 2 100x100 matrices.
