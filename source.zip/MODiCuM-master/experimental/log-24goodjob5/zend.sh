
#END SESSSION
pkill tmux
fab -H 172.21.20.61 runCommand:"sudo pkill tmux; sudo pkill python3"
fab -H 172.21.20.63 runCommand:"sudo pkill tmux; sudo pkill python3"
fab -H 172.21.20.51 runCommand:"sudo pkill tmux; sudo pkill python3"
fab -H 172.21.20.53 runCommand:"sudo pkill tmux; sudo pkill python3"
fab -H 172.21.20.59 runCommand:"sudo pkill tmux; sudo pkill python3"
