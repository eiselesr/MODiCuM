#!/bin/bash
# ag=matrix_multiplication:latest
# imageHash_int=81149553402290126336912759121443951032289048415197312414029918919630037417258
# tarHash_int=64285916272592554459968489203248987031170744719502649171752662073818162493438
# job_size=100808704 #bytes
# cpu=2430000000 #ns
# memory=5197824 #bytes
#
# echo $memory
# make startBC
# export HISTIGNORE='*sudo -S*'
source ./.env
# BBBs
JCip=172.21.20.61
RPip=172.21.20.63
#
# CREATE SESSIONS
tmux new-session -d -s CM
tmux new-session -d -s DIR
tmux new-session -d -s S
tmux new -d -s M
cmd="tmux new -d -s JCD"
fab -H 172.21.20.61 runCommand:"$cmd"
fab -H 172.21.20.51 runCommand:"tmux new -d -s RPD"
fab -H 172.21.20.53 runCommand:"tmux new -d -s RPD"
fab -H 172.21.20.59 runCommand:"tmux new -d -s RPD"
fab -H 172.21.20.63 runCommand:"tmux new -d -s RPD"

# RUN COMMANDS
fab -H 172.21.20.51 runCommand:"touch modicum.log"
fab -H 172.21.20.53 runCommand:"touch modicum.log"
fab -H 172.21.20.61 runCommand:"touch modicum.log"
fab -H 172.21.20.63 runCommand:"touch modicum.log"
fab -H 172.21.20.61 runCommand:"touch modicum.log"
fab -H 172.21.20.59 runCommand:"touch modicum.log"

#make startBC
tmux send -t CM 'echo $pass | sudo -S modicum runAsCM --index 0' ENTER
tmux send -t DIR 'echo $pass | sudo -S modicum runAsDir' ENTER
tmux send -t S 'echo $pass | sudo -S modicum runAsSolver --index 2' ENTER
tmux send -t M 'echo $pass | sudo -S modicum runAsMediator --index 3' ENTER
fab -H 172.21.20.61 runCommand:"tmux send -t JCD 'sudo -S modicum startJCDaemon --index 4' ENTER"
fab -H 172.21.20.63 runCommand:"tmux send -t RPD 'sudo modicum startRPDaemon --index 5' ENTER"
fab -H 172.21.20.51 runCommand:"tmux send -t RPD 'sudo modicum startRPDaemon --index 6' ENTER"
fab -H 172.21.20.53 runCommand:"tmux send -t RPD 'sudo modicum startRPDaemon --index 7' ENTER"
fab -H 172.21.20.59 runCommand:"tmux send -t RPD 'sudo modicum startRPDaemon --index 8' ENTER"

echo Done starting platform

# sleep 120
# ./zwarm.sh
