It used myInput3.json which are 2 1000x1000 matrices.
