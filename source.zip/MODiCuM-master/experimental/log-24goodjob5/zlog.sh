#FETCH LOGS
stamp=$(date -d "today" +"%Y_%m_%d_%H_%M")

rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.61:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node61.log

rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.63:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node63.log


rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.51:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node51.log


rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.53:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node53.log


rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.59:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node59.log


mv /home/riaps/projects/MODiCuM/src/python/modicum.log ./logs/"$stamp"_node1.log
