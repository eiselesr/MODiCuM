fab -H 172.21.20.61 runCommand:"modicum JCaddMediator"
fab -H 172.21.20.63 runCommand:"modicum RPaddMediator"
fab -H 172.21.20.51 runCommand:"modicum RPaddMediator"
fab -H 172.21.20.53 runCommand:"modicum RPaddMediator"
fab -H 172.21.20.59 runCommand:"modicum RPaddMediator"

echo Done adding Mediators

# sleep 30
# ./ztrace.sh
