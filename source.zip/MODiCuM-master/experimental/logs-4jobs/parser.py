import csv
import os
import contextlib

with contextlib.suppress(FileNotFoundError):
    os.remove("logs.csv")

with open ("logs.csv", 'a') as csvfile:
    fieldnames = ['timestamp','actor', 'event']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    dir = os.getcwd()
    for root,dirs, files in os.walk(dir):
        print(files)
        for filename in files:
            if "node" in filename:
                with open(dir+'/'+filename, 'r') as f:
                    for line in f:
                        l = line.split(";")
                        if (
                        # "{'request': 'query_contract_address'}" in line or
                        "Deploying contract" in line or
                        "Contract Submitted" in line or
                        "Z:" in line or
                        "A:" in line or #Registration
                        "B:" in line or #mediator
                        "C:" in line or #Resource offer
                        ("D:" in line and "container" not in line) or #Job offer
                        "E:" in line or #Job offer image
                        "Begin Matching" in line or
                        "Matchable" in line or
                        "I:" in line or
                        "F:" in line or
                        "M:" in line ): #match closed
                            time = l[0]
                            actor = l[1]
                            event = l[2]
                            row = {'timestamp':time,
                                   'actor': actor,
                                   'event':event}
                            writer.writerow(row)
