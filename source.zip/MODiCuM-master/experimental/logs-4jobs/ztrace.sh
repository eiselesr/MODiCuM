fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput0.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"
fab -H 172.21.20.61 runCommand:"modicum postJob"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer"
fab -H 172.21.20.61 runCommand:"modicum wait4Completion"

fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput1.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"
fab -H 172.21.20.61 runCommand:"modicum postJob"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer"
fab -H 172.21.20.61 runCommand:"modicum wait4Completion"

fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput2.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"
fab -H 172.21.20.61 runCommand:"modicum postJob"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer"
fab -H 172.21.20.61 runCommand:"modicum wait4Completion"

fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput3.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"
fab -H 172.21.20.61 runCommand:"modicum postJob"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer"
fab -H 172.21.20.61 runCommand:"modicum wait4Completion"

#FETCH LOGS
stamp=$(date -d "today" +"%Y_%m_%d_%H_%M")
rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.61:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node61.log
rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_2018_9_10" riaps@172.21.20.63:~/modicum.log ./logs
mv ./logs/modicum.log ./logs/"$stamp"_node63.log
mv /home/riaps/projects/MODiCuM/src/python/modicum.log ./logs/"$stamp"_node1.log

#END SESSSION
pkill tmux
fab -H 172.21.20.61 runCommand:"sudo pkill tmux; sudo pkill python3"
fab -H 172.21.20.63 runCommand:"sudo pkill tmux; sudo pkill python3"
