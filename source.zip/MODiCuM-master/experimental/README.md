Experimental Scenarios

* computation cost in terms of blockchain
* timing how well does this work
* how much bandwidth that people are using.
* if you have extra energy then you can provide computation at zero cost.
* Ability to delay the scheduling oj jobs
* How the system  deter malicious participants. In what case the people will participate. mediators can go offline with some probability.
* what combination of verification rate you need to set to deter malicious intent -- basic analysis.
