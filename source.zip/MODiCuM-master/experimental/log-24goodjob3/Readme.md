This is the first run that had updated logging which allowed a job to be followed through each of the phases.

It used myInput1.json which are 2 100x100 matrices.
