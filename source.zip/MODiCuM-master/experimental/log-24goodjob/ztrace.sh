fab -H 172.21.20.61 runCommand:"cp \
/home/riaps/projects/MODiCuM/src/python/matrix/inputs/myInput3.json \
/home/riaps/projects/MODiCuM/src/python/matrix/input/myInput.json"

# fab -H 172.21.20.61 runCommand:"modicum publishJob --input True --image True"
fab -H 172.21.20.61 runCommand:"modicum publishJob --input True"

# fab -H 172.21.20.61 runCommand:"modicum publishJob"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 101"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 102"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 103"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 104"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 1"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 2"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 3"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 4"

fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 105"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 106"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 107"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 108"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 5"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 6"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 7"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 8"

fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 109"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 110"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 111"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 112"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 9"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 10"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 11"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 12"

fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 113"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 114"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 115"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 116"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 13"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 14"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 15"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 16"

fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 117"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 118"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 119"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 120"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 17"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 18"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 19"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 20"

fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 121"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 122"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 123"
fab -H 172.21.20.61 runCommand:"modicum postJob --myoid 124"
fab -H 172.21.20.63 runCommand:"modicum RPpostOffer --myoid 21"
fab -H 172.21.20.51 runCommand:"modicum RPpostOffer --myoid 22"
fab -H 172.21.20.53 runCommand:"modicum RPpostOffer --myoid 23"
fab -H 172.21.20.59 runCommand:"modicum RPpostOffer --myoid 24"

echo "Done"

# fab -H 172.21.20.61 runCommand:"modicum wait4Completion"


#FETCH LOGS
# stamp=$(date -d "today" +"%Y_%m_%d_%H_%M")
# rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_1008_9_10" riaps@172.21.20.61:~/modicum.log ./logs
# mv ./logs/modicum.log ./logs/"$stamp"_node61.log
# rsync -v --remove-source-files -e "ssh -p222 -i /home/riaps/.ssh/cluster_1008_9_10" riaps@172.21.20.63:~/modicum.log ./logs
# mv ./logs/modicum.log ./logs/"$stamp"_node63.log
# mv /home/riaps/projects/MODiCuM/src/python/modicum.log ./logs/"$stamp"_node1.log
#
# #END SESSSION
# pkill tmux
# fab -H 172.21.20.61 runCommand:"sudo pkill tmux; sudo pkill python3"
# fab -H 172.21.20.63 runCommand:"sudo pkill tmux; sudo pkill python3"
