This is the first run that had updated logging which included tags for getting execution time with the job_id

It used myInput1.json which are 2 100x100 matrices.
