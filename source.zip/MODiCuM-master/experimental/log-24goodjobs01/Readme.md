Hopefully I'm finally logging enough. 
It used myInput1.json which are 2 10x10 matrices.
